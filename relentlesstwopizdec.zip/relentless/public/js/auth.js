// Authentication API functions
const API = {
    async register(name, email, password) {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });
        return response.json();
    },

    async verifyEmail(email, code) {
        const response = await fetch('/api/verify-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, code })
        });
        return response.json();
    },

    async resendVerification(email) {
        const response = await fetch('/api/resend-verification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        return response.json();
    },

    async login(email, password) {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        return response.json();
    },

    async verify2FA(email, code) {
        const response = await fetch('/api/verify-2fa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, code })
        });
        return response.json();
    },

    async logout() {
        const response = await fetch('/api/logout', {
            method: 'POST'
        });
        return response.json();
    },

    async getCurrentUser() {
        const response = await fetch('/api/user');
        if (response.ok) {
            return response.json();
        }
        return null;
    },

    async getPurchases() {
        const response = await fetch('/api/purchases');
        if (response.ok) {
            return response.json();
        }
        return { purchases: [] };
    },

    async getLicenses() {
        const response = await fetch('/api/licenses');
        if (response.ok) {
            return response.json();
        }
        return { licenses: [] };
    },

    async getActiveLicenses() {
        const response = await fetch('/api/licenses/active');
        if (response.ok) {
            return response.json();
        }
        return { licenses: [] };
    },

    async resetHWID(licenseKey) {
        const response = await fetch('/api/licenses/reset-hwid', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey })
        });
        return response.json();
    },

    async submitSupport(name, email, message) {
        const response = await fetch('/api/support', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, message })
        });
        return response.json();
    },

    async getTickets() {
        const response = await fetch('/api/support/tickets');
        return response.json();
    },

    async verifyPayment(paymentData) {
        const response = await fetch('/api/payment/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(paymentData)
        });
        return response.json();
    }
};

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 10);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Global variables for verification
let pendingVerificationEmail = null;
let pending2FAEmail = null;

// Check if user is logged in on page load
async function checkAuth() {
    const user = await API.getCurrentUser();
    if (user && user.user) {
        updateUIForLoggedInUser(user.user);
    }
}

function updateUIForLoggedInUser(user) {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    
    if (loginBtn && registerBtn) {
        loginBtn.innerHTML = `<span>${user.name}</span>`;
        loginBtn.onclick = () => {
            openAccountSection(user);
        };
        
        registerBtn.innerHTML = '<span>Logout</span>';
        registerBtn.onclick = async () => {
            await API.logout();
            showNotification('Logged out successfully');
            setTimeout(() => location.reload(), 1000);
        };
    }
}

// Open account section
function openAccountSection(user) {
    document.querySelector('.hero').style.display = 'none';
    document.getElementById('featuresSection').classList.add('section-hidden');
    document.getElementById('pricesSection').classList.add('section-hidden');
    document.getElementById('pricesInternalSection').classList.add('section-hidden');
    document.getElementById('supportSection').classList.add('section-hidden');
    
    const accountSection = document.getElementById('accountSection');
    accountSection.classList.remove('section-hidden');
    
    document.getElementById('accountName').textContent = user.name;
    document.getElementById('accountEmail').textContent = user.email;
    
    const memberSince = document.getElementById('accountMemberSince');
    if (user.createdAt) {
        const date = new Date(user.createdAt);
        memberSince.textContent = date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
    } else {
        memberSince.textContent = 'Recently';
    }
    
    const statusBadge = document.getElementById('accountStatusBadge');
    const subscriptionDetails = document.getElementById('accountSubscriptionDetails');
    const manageBtn = document.getElementById('accountManageSubscriptionBtn');
    
    if (user.subscription) {
        statusBadge.textContent = 'Active';
        statusBadge.className = 'status-badge status-active';
        subscriptionDetails.innerHTML = `
            <p><strong>Plan:</strong> ${user.subscription.plan}</p>
            <p><strong>Expires:</strong> ${new Date(user.subscription.expiresAt).toLocaleDateString()}</p>
        `;
        manageBtn.textContent = 'Renew Subscription';
    } else {
        statusBadge.textContent = 'No Active Subscription';
        statusBadge.className = 'status-badge status-inactive';
        subscriptionDetails.innerHTML = '<p>Get started with a subscription to access all features</p>';
        manageBtn.textContent = 'Get Subscription';
    }
    
    // Load purchase history
    loadPurchaseHistory();
    
    // Load licenses
    loadLicenses();
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Load licenses
async function loadLicenses() {
    const result = await API.getLicenses();
    const container = document.getElementById('licensesContainer');
    
    if (!container) return;
    
    if (result.licenses && result.licenses.length > 0) {
        let html = '<div class="license-list">';
        result.licenses.forEach(license => {
            const isActive = license.active && new Date(license.expires_at) > new Date();
            const statusClass = isActive ? 'license-active' : 'license-expired';
            const statusText = isActive ? 'Active' : 'Expired';
            const expiryDate = new Date(license.expires_at).toLocaleDateString();
            
            html += `
                <div class="license-item ${statusClass}">
                    <div class="license-header">
                        <div class="license-key">${license.license_key}</div>
                        <div class="license-status">${statusText}</div>
                    </div>
                    <div class="license-details">
                        <div class="license-info">
                            <span>Plan: ${license.plan}</span>
                            <span>Type: ${license.type}</span>
                            <span>Expires: ${expiryDate}</span>
                            ${license.hwid ? '<span>HWID: Bound</span>' : '<span>HWID: Not bound</span>'}
                        </div>
                        <div class="license-actions">
                            <button class="btn-copy-license" data-key="${license.license_key}" title="Copy license key">📋 Copy</button>
                            ${license.hwid && isActive ? `<button class="btn-reset-hwid" data-key="${license.license_key}" title="Reset HWID">🔄 Reset HWID</button>` : ''}
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
        
        // Add event listeners
        document.querySelectorAll('.btn-copy-license').forEach(btn => {
            btn.addEventListener('click', function() {
                const key = this.getAttribute('data-key');
                navigator.clipboard.writeText(key).then(() => {
                    showNotification('License key copied!');
                });
            });
        });
        
        document.querySelectorAll('.btn-reset-hwid').forEach(btn => {
            btn.addEventListener('click', async function() {
                const key = this.getAttribute('data-key');
                if (confirm('Reset HWID for this license? You will need to re-bind it on next use.')) {
                    const result = await API.resetHWID(key);
                    if (result.success) {
                        showNotification('HWID reset successfully!');
                        loadLicenses(); // Reload
                    } else {
                        showNotification(result.error || 'Failed to reset HWID', 'error');
                    }
                }
            });
        });
    } else {
        container.innerHTML = '<p style="color: #a1a1a6;">No licenses yet. Purchase a subscription to get your license key.</p>';
    }
}

// Load purchase history
async function loadPurchaseHistory() {
    const result = await API.getPurchases();
    const container = document.getElementById('purchaseHistoryContainer');
    
    if (!container) return;
    
    if (result.purchases && result.purchases.length > 0) {
        let html = '<div class="purchase-list">';
        result.purchases.forEach(purchase => {
            const date = new Date(purchase.created_at).toLocaleDateString();
            html += `
                <div class="purchase-item">
                    <div class="purchase-info">
                        <strong>${purchase.plan}</strong>
                        <span>${date}</span>
                    </div>
                    <div class="purchase-price">${purchase.price}</div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    } else {
        container.innerHTML = '<p style="color: #a1a1a6;">No purchases yet</p>';
    }
}

// Initialize auth check
checkAuth();
