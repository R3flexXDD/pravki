#pragma once

#define IDD_MAIN 102
#define IDC_INJECT 1001
#define IDC_STATUS 1002
#define IDC_LICENSE 1003
#define IDC_HWID_LABEL 1004
#define IDC_LICENSE_LABEL 1005
#define IDC_STATUS_LABEL 1006
