// RELENTLESS Loader - Fatality-Level Protection
// Kablykteam © 2026
//
// ЗАЩИТА (ВСЕ ФИЧИ):
// 1. Process Killer - убивает отладчики по имени процесса И по названию окна (если переименовали)
// 2. String Encryption - все строки зашифрованы (SERVER_URL, "cs2.exe" и т.д.)
// 3. Anti-Debug - 4 метода детекта отладчиков
// 4. Anti-VM - детект виртуальных машин и sandbox
// 5. Anti-Dump - защита памяти после инжекта (нельзя дампнуть DLL)
// 6. Integrity Check - проверка что лоадер не пропатчен
// 7. Anti-Screenshot/Recording - окно черное на скриншотах, детект OBS/Bandicam
// 8. Enhanced HWID - CPU + HDD + MAC + BIOS (сложнее обойти бан)
// 9. Time Bomb - детект изменения системного времени
// 10. Memory Scanning - поиск известных кряков/патчей в памяти
// 11. API Hook Detection - проверка что WinAPI не захукан
// 12. Fake Flags - ловушки для кракеров (если изменят → автобан)
// 13. Code Obfuscation - фейковые проверки для запутывания
// 14. Online Auth - авторизация через сервер (HWID + License)
// 15. Code Mutation - каждая загрузка DLL уникальна (сервер добавляет случайные байты)
// 16. Heartbeat - проверка каждые 30 сек, если забанен → self-destruct
// 17. Self-Destruct - удаляет себя при обнаружении кряка
//
// КАК НАСТРОИТЬ:
// 1. Измени ENCRYPTED_SERVER_URL на свой домен (строка 50-60)
// 2. Собери loader.exe
// 3. Запусти один раз - он выведет checksum в консоль
// 4. Вставь checksum в EXPECTED_CHECKSUM (строка ~280)
// 5. Пересобери - готово!

#include <Windows.h>
#include <CommCtrl.h>
#include <intrin.h>
#include <tlhelp32.h>
#include <wininet.h>
#include <iphlpapi.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <thread>
#include <atomic>
#include <ctime>
#include "resource.h"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "dwmapi.lib")

// Server configuration - ENCRYPTED (see DecryptString below)
#define HEARTBEAT_INTERVAL 30000 // 30 seconds

// Simple XOR string encryption (compile-time)
constexpr char XOR_KEY = 0x7A;

constexpr char EncryptChar(char c) {
    return c ^ XOR_KEY;
}

// Encrypted strings (расшифровываются в рантайме)
constexpr char ENCRYPTED_SERVER_URL[] = {
    EncryptChar('h'), EncryptChar('t'), EncryptChar('t'), EncryptChar('p'), EncryptChar('s'),
    EncryptChar(':'), EncryptChar('/'), EncryptChar('/'),
    EncryptChar('r'), EncryptChar('e'), EncryptChar('l'), EncryptChar('e'), EncryptChar('t'),
    EncryptChar('n'), EncryptChar('l'), EncryptChar('e'), EncryptChar('s'), EncryptChar('s'),
    EncryptChar('.'), EncryptChar('s'), EncryptChar('u'),
    EncryptChar('/'), EncryptChar('a'), EncryptChar('p'), EncryptChar('i'), '\0'
};

constexpr char ENCRYPTED_CS2_EXE[] = {
    EncryptChar('c'), EncryptChar('s'), EncryptChar('2'), EncryptChar('.'), EncryptChar('e'), EncryptChar('x'), EncryptChar('e'), '\0'
};

// Decrypt string helper
std::string DecryptString(const char* encrypted) {
    std::string result;
    for (int i = 0; encrypted[i] != '\0'; i++) {
        result += (encrypted[i] ^ XOR_KEY);
    }
    return result;
}

class Loader {
private:
    HWND hDlg;
    HWND hStatus;
    HWND hInject;
    
    std::string hwid;
    std::string sessionToken;
    std::vector<BYTE> dllData;
    std::atomic<bool> heartbeatRunning;
    std::thread heartbeatThread;
    time_t startTime; // Для Time Bomb
    BYTE fakeFlag1; // Ловушка для кракеров
    BYTE fakeFlag2; // Ловушка для кракеров
    
    // Process killer - kill debuggers before showing GUI
    void KillDebuggers() {
        const char* debuggers[] = {
            "x64dbg.exe", "x32dbg.exe", "ida.exe", "ida64.exe",
            "ollydbg.exe", "windbg.exe", "cheatengine-x86_64.exe",
            "processhacker.exe", "procexp.exe", "procexp64.exe",
            "dnspy.exe", "ghidra.exe", "idaq.exe", "idaq64.exe",
            "scylla_x64.exe", "scylla_x86.exe", "protection_id.exe",
            "lordpe.exe", "importrec.exe", "immunitydebugger.exe"
        };
        
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
            return;
        
        PROCESSENTRY32 entry;
        entry.dwSize = sizeof(PROCESSENTRY32);
        
        if (Process32First(snapshot, &entry)) {
            do {
                // Check by process name
                for (const char* debugger : debuggers) {
                    if (_stricmp(entry.szExeFile, debugger) == 0) {
                        HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, entry.th32ProcessID);
                        if (hProcess) {
                            TerminateProcess(hProcess, 0);
                            CloseHandle(hProcess);
                        }
                    }
                }
            } while (Process32Next(snapshot, &entry));
        }
        
        CloseHandle(snapshot);
        
        // ДОПОЛНИТЕЛЬНО: Детект по названию окна (если переименовали процесс)
        // x64dbg всегда имеет окно с "x64dbg" в заголовке
        const char* debuggerWindows[] = {
            "x64dbg", "x32dbg", "IDA", "OllyDbg", "WinDbg",
            "Cheat Engine", "Process Hacker", "dnSpy", "Ghidra"
        };
        
        for (const char* windowTitle : debuggerWindows) {
            HWND hwnd = FindWindowA(NULL, NULL);
            while (hwnd != NULL) {
                char title[256];
                GetWindowTextA(hwnd, title, sizeof(title));
                
                // Если в заголовке окна есть название отладчика
                if (strstr(title, windowTitle) != NULL) {
                    DWORD processId;
                    GetWindowThreadProcessId(hwnd, &processId);
                    
                    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, processId);
                    if (hProcess) {
                        TerminateProcess(hProcess, 0);
                        CloseHandle(hProcess);
                    }
                }
                
                hwnd = GetWindow(hwnd, GW_HWNDNEXT);
            }
        }
    }
    
    // Enhanced anti-debug checks
    bool DetectDebugger() {
        // IsDebuggerPresent
        if (IsDebuggerPresent())
            return true;
        
        // CheckRemoteDebuggerPresent
        BOOL isDebuggerPresent = FALSE;
        CheckRemoteDebuggerPresent(GetCurrentProcess(), &isDebuggerPresent);
        if (isDebuggerPresent)
            return true;
        
        // NtQueryInformationProcess
        typedef NTSTATUS(WINAPI* pNtQueryInformationProcess)(HANDLE, UINT, PVOID, ULONG, PULONG);
        HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
        if (hNtdll) {
            pNtQueryInformationProcess NtQIP = (pNtQueryInformationProcess)GetProcAddress(hNtdll, "NtQueryInformationProcess");
            if (NtQIP) {
                DWORD debugPort = 0;
                NTSTATUS status = NtQIP(GetCurrentProcess(), 7, &debugPort, sizeof(debugPort), NULL);
                if (status == 0 && debugPort != 0)
                    return true;
            }
        }
        
        // Hardware breakpoints
        CONTEXT ctx = {};
        ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
        if (GetThreadContext(GetCurrentThread(), &ctx)) {
            if (ctx.Dr0 != 0 || ctx.Dr1 != 0 || ctx.Dr2 != 0 || ctx.Dr3 != 0)
                return true;
        }
        
        return false;
    }
    
    // Detect VM/Sandbox
    bool DetectVM() {
        // Check for VM processes
        const char* vmProcesses[] = {
            "vmtoolsd.exe", "vmwaretray.exe", "vmwareuser.exe",
            "vboxservice.exe", "vboxtray.exe", "sandboxie.exe",
            "wireshark.exe", "fiddler.exe"
        };
        
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 entry;
            entry.dwSize = sizeof(PROCESSENTRY32);
            
            if (Process32First(snapshot, &entry)) {
                do {
                    for (const char* vmProc : vmProcesses) {
                        if (_stricmp(entry.szExeFile, vmProc) == 0) {
                            CloseHandle(snapshot);
                            return true;
                        }
                    }
                } while (Process32Next(snapshot, &entry));
            }
            CloseHandle(snapshot);
        }
        
        // Check for VM registry keys
        HKEY hKey;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services\\VBoxGuest", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
            RegCloseKey(hKey);
            return true;
        }
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE\\VMware, Inc.\\VMware Tools", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
            RegCloseKey(hKey);
            return true;
        }
        
        return false;
    }
    
    // Anti-Dump: Защита от дампа DLL из памяти
    void ProtectMemory() {
        // Делаем секции памяти PAGE_NOACCESS после инжекта
        // Это усложняет дамп DLL из памяти процесса
        if (!dllData.empty()) {
            DWORD oldProtect;
            VirtualProtect(dllData.data(), dllData.size(), PAGE_NOACCESS, &oldProtect);
        }
    }
    
    // Integrity Check: Проверка что лоадер не пропатчен
    bool CheckIntegrity() {
        // Получаем путь к loader.exe
        char exePath[MAX_PATH];
        GetModuleFileNameA(NULL, exePath, MAX_PATH);
        
        // Читаем файл
        std::ifstream file(exePath, std::ios::binary);
        if (!file.is_open())
            return false;
        
        // Считаем простой хеш (XOR всех байт)
        BYTE checksum = 0;
        char byte;
        while (file.read(&byte, 1)) {
            checksum ^= byte;
        }
        file.close();
        
        // Сравниваем с ожидаемым хешем
        // ВАЖНО: После компиляции запусти лоадер один раз, он выведет хеш
        // Потом вставь этот хеш сюда вместо 0x00
        const BYTE EXPECTED_CHECKSUM = 0x00; // ЗАМЕНИ ПОСЛЕ ПЕРВОЙ КОМПИЛЯЦИИ
        
        // Если хеш = 0x00, значит еще не настроен, пропускаем проверку
        if (EXPECTED_CHECKSUM == 0x00)
            return true;
        
        return (checksum == EXPECTED_CHECKSUM);
    }
    
    // Anti-Screenshot: Делает окно черным на скриншотах/записи
    void EnableAntiScreenshot() {
        // SetWindowDisplayAffinity делает окно невидимым для захвата экрана
        SetWindowDisplayAffinity(hDlg, WDA_EXCLUDEFROMCAPTURE);
    }
    
    // Детект программ записи экрана
    bool DetectRecording() {
        const char* recorders[] = {
            "obs64.exe", "obs32.exe", "obs.exe",
            "bandicam.exe", "fraps.exe", "xsplit.core.exe",
            "action.exe", "camtasia.exe", "nvidia share.exe"
        };
        
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 entry;
            entry.dwSize = sizeof(PROCESSENTRY32);
            
            if (Process32First(snapshot, &entry)) {
                do {
                    for (const char* recorder : recorders) {
                        if (_stricmp(entry.szExeFile, recorder) == 0) {
                            CloseHandle(snapshot);
                            return true;
                        }
                    }
                } while (Process32Next(snapshot, &entry));
            }
            CloseHandle(snapshot);
        }
        
        return false;
    }
    
    // Enhanced HWID: Добавляем MAC адрес и BIOS serial
    std::string GetEnhancedHWID() {
        std::stringstream ss;
        
        // CPU ID
        int cpuInfo[4] = {0};
        __cpuid(cpuInfo, 0);
        ss << std::hex << std::setfill('0');
        ss << std::setw(8) << cpuInfo[1];
        ss << std::setw(8) << cpuInfo[3];
        ss << std::setw(8) << cpuInfo[2];
        
        // HDD Serial
        DWORD serial = 0;
        GetVolumeInformationA("C:\\", NULL, 0, &serial, NULL, NULL, NULL, 0);
        ss << std::setw(8) << serial;
        
        // MAC Address
        IP_ADAPTER_INFO adapterInfo[16];
        DWORD bufferSize = sizeof(adapterInfo);
        if (GetAdaptersInfo(adapterInfo, &bufferSize) == NO_ERROR) {
            for (int i = 0; i < 6; i++) {
                ss << std::setw(2) << (int)adapterInfo[0].Address[i];
            }
        }
        
        // BIOS Serial (через WMI или registry)
        HKEY hKey;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\BIOS", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
            char biosSerial[256];
            DWORD size = sizeof(biosSerial);
            if (RegQueryValueExA(hKey, "SystemProductName", NULL, NULL, (LPBYTE)biosSerial, &size) == ERROR_SUCCESS) {
                for (DWORD i = 0; i < size && biosSerial[i] != '\0'; i++) {
                    ss << std::setw(2) << (int)biosSerial[i];
                }
            }
            RegCloseKey(hKey);
        }
        
        return ss.str();
    }
    
    // Time Bomb: Проверка системного времени
    bool CheckSystemTime() {
        time_t currentTime = time(NULL);
        
        // Проверка 1: Время не изменилось назад
        if (startTime > 0 && currentTime < startTime) {
            return false; // Время откатили назад
        }
        
        // Проверка 2: Время не слишком далеко в будущем
        struct tm* timeinfo = localtime(&currentTime);
        if (timeinfo->tm_year + 1900 > 2030) {
            return false; // Подозрительно далекое будущее
        }
        
        // Проверка 3: Время не слишком в прошлом
        if (timeinfo->tm_year + 1900 < 2024) {
            return false; // Слишком старая дата
        }
        
        startTime = currentTime;
        return true;
    }
    
    // Memory Scanning: Поиск известных кряков в памяти
    bool ScanMemoryForCracks() {
        // Сигнатуры известных кряков/патчей (примеры)
        const BYTE crack_sig1[] = {0x90, 0x90, 0x90, 0x90, 0x90}; // NOP sled
        const BYTE crack_sig2[] = {0xEB, 0xFE}; // JMP $
        const BYTE crack_sig3[] = {0xC3}; // RET (ранний выход)
        
        // Получаем информацию о памяти процесса
        MEMORY_BASIC_INFORMATION mbi;
        LPVOID address = NULL;
        
        while (VirtualQuery(address, &mbi, sizeof(mbi))) {
            // Проверяем только исполняемые секции
            if (mbi.State == MEM_COMMIT && (mbi.Protect & PAGE_EXECUTE_READ)) {
                BYTE* buffer = new BYTE[mbi.RegionSize];
                SIZE_T bytesRead;
                
                if (ReadProcessMemory(GetCurrentProcess(), mbi.BaseAddress, buffer, mbi.RegionSize, &bytesRead)) {
                    // Ищем сигнатуры
                    for (SIZE_T i = 0; i < bytesRead - 5; i++) {
                        // Проверка на NOP sled (5+ NOP подряд = подозрительно)
                        if (memcmp(&buffer[i], crack_sig1, sizeof(crack_sig1)) == 0) {
                            delete[] buffer;
                            return true; // Найден патч
                        }
                    }
                }
                
                delete[] buffer;
            }
            
            address = (LPVOID)((DWORD_PTR)mbi.BaseAddress + mbi.RegionSize);
        }
        
        return false;
    }
    
    // API Hook Detection: Проверка что WinAPI не захукан
    bool DetectAPIHooks() {
        // Проверяем важные функции
        HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
        HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
        
        if (!hKernel32 || !hNtdll)
            return false;
        
        // Получаем адреса функций
        LPVOID pLoadLibrary = GetProcAddress(hKernel32, "LoadLibraryA");
        LPVOID pCreateThread = GetProcAddress(hKernel32, "CreateThread");
        LPVOID pVirtualAlloc = GetProcAddress(hKernel32, "VirtualAlloc");
        
        // Проверяем первые байты функций
        // Если функция захукана, первые байты будут JMP/CALL
        BYTE* bytes = (BYTE*)pLoadLibrary;
        
        // Проверка на JMP (0xE9) или CALL (0xE8)
        if (bytes[0] == 0xE9 || bytes[0] == 0xE8) {
            return true; // Функция захукана
        }
        
        // Проверка на inline hook (MOV + JMP)
        if (bytes[0] == 0x48 && bytes[1] == 0xB8) { // MOV RAX, imm64
            return true; // Inline hook
        }
        
        return false;
    }
    
    // Fake Flags: Ловушки для кракеров
    void InitFakeFlags() {
        // Эти флаги выглядят как "защита отключена"
        // Если кракер их изменит → мы узнаем
        fakeFlag1 = 0x00; // Выглядит как "anti-debug disabled"
        fakeFlag2 = 0x00; // Выглядит как "integrity check disabled"
    }
    
    bool CheckFakeFlags() {
        // Если кракер изменил флаги (думая что отключил защиту)
        if (fakeFlag1 != 0x00 || fakeFlag2 != 0x00) {
            // Тихо отправляем HWID на бан
            std::string postData = "hwid=" + hwid + "&reason=fake_flag_modified";
            HttpRequest("/ban.php", postData);
            return false;
        }
        return true;
    }
    
    // Code Obfuscation: Фейковые проверки для запутывания
    void ObfuscatedCheck1() {
        // Фейковая проверка которая ничего не делает
        // Но выглядит важной для кракера
        volatile int x = 0;
        for (int i = 0; i < 100; i++) {
            x += i * 2;
            x -= i;
        }
        // Результат не используется
    }
    
    void ObfuscatedCheck2() {
        // Еще одна фейковая проверка
        volatile DWORD tick = GetTickCount();
        Sleep(1);
        volatile DWORD tick2 = GetTickCount();
        // Выглядит как anti-debug timing check, но это обманка
    }
    
    // Self-destruct mechanism
    void SelfDestruct() {
        // Delete license file
        DeleteFileA("license.rls");
        
        // Create batch file to delete loader
        char tempPath[MAX_PATH];
        GetTempPathA(MAX_PATH, tempPath);
        std::string batPath = std::string(tempPath) + "cleanup.bat";
        
        std::ofstream bat(batPath);
        if (bat.is_open()) {
            char exePath[MAX_PATH];
            GetModuleFileNameA(NULL, exePath, MAX_PATH);
            
            bat << "@echo off\n";
            bat << "timeout /t 2 /nobreak >nul\n";
            bat << "del \"" << exePath << "\"\n";
            bat << "del \"%~f0\"\n";
            bat.close();
            
            ShellExecuteA(NULL, "open", batPath.c_str(), NULL, NULL, SW_HIDE);
        }
        
        ExitProcess(0);
    }
    
    void UpdateStatus(const std::string& msg) {
        if (hStatus) {
            SetWindowTextA(hStatus, msg.c_str());
        }
    }
    
    
    
    std::string GetHWID() {
        // Используем Enhanced HWID (CPU + HDD + MAC + BIOS)
        return GetEnhancedHWID();
    }
    
    
    // HTTP request helper
    std::string HttpRequest(const std::string& endpoint, const std::string& postData = "") {
        std::string serverUrl = DecryptString(ENCRYPTED_SERVER_URL);
        std::string url = serverUrl + endpoint;
        std::string response;
        
        HINTERNET hInternet = InternetOpenA("RELENTLESS/1.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
        if (!hInternet)
            return "";
        
        HINTERNET hConnect = InternetOpenUrlA(hInternet, url.c_str(), 
                                              postData.empty() ? NULL : postData.c_str(),
                                              postData.size(), 
                                              INTERNET_FLAG_SECURE | INTERNET_FLAG_NO_CACHE_WRITE, 0);
        
        if (hConnect) {
            char buffer[4096];
            DWORD bytesRead;
            
            while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
                response.append(buffer, bytesRead);
            }
            
            InternetCloseHandle(hConnect);
        }
        
        InternetCloseHandle(hInternet);
        return response;
    }
    
    // Online authentication
    bool Authenticate(const std::string& license) {
        UpdateStatus("Authenticating...");
        
        std::string postData = "hwid=" + hwid + "&license=" + license;
        std::string response = HttpRequest("/auth.php", postData);
        
        if (response.empty()) {
            UpdateStatus("Connection failed!");
            return false;
        }
        
        // Parse response: SUCCESS:token or ERROR:message
        if (response.substr(0, 7) == "SUCCESS") {
            size_t pos = response.find(':');
            if (pos != std::string::npos) {
                sessionToken = response.substr(pos + 1);
                return true;
            }
        } else if (response.substr(0, 6) == "BANNED") {
            UpdateStatus("HWID BANNED!");
            MessageBoxA(hDlg, "Your HWID has been banned!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
        }
        
        UpdateStatus("Invalid license!");
        return false;
    }
    
    // Download encrypted DLL from server
    bool DownloadDLL() {
        UpdateStatus("Downloading...");
        
        std::string postData = "token=" + sessionToken;
        std::string response = HttpRequest("/download.php", postData);
        
        if (response.empty() || response.size() < 1000) {
            UpdateStatus("Download failed!");
            return false;
        }
        
        // Decrypt DLL (XOR with session token)
        dllData.resize(response.size());
        for (size_t i = 0; i < response.size(); i++) {
            dllData[i] = response[i] ^ sessionToken[i % sessionToken.size()];
        }
        
        UpdateStatus("DLL downloaded");
        return true;
    }
    
    // Heartbeat thread
    void HeartbeatLoop() {
        while (heartbeatRunning) {
            Sleep(HEARTBEAT_INTERVAL);
            
            if (!heartbeatRunning)
                break;
            
            std::string postData = "token=" + sessionToken;
            std::string response = HttpRequest("/heartbeat.php", postData);
            
            if (response != "OK") {
                // Session invalid or banned
                MessageBoxA(NULL, "Session expired or banned!", "RELENTLESS", MB_OK | MB_ICONERROR);
                SelfDestruct();
            }
        }
    }
    
    
    
    DWORD FindCS2Process() {
        std::string cs2Name = DecryptString(ENCRYPTED_CS2_EXE);
        
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
            return 0;
        
        PROCESSENTRY32 entry;
        entry.dwSize = sizeof(PROCESSENTRY32);
        
        if (Process32First(snapshot, &entry)) {
            do {
                if (_stricmp(entry.szExeFile, cs2Name.c_str()) == 0) {
                    CloseHandle(snapshot);
                    return entry.th32ProcessID;
                }
            } while (Process32Next(snapshot, &entry));
        }
        
        CloseHandle(snapshot);
        return 0;
    }
    
    bool InjectDLL(DWORD processId) {
        HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
        if (!hProcess) {
            UpdateStatus("Failed to open CS2!");
            return false;
        }
        
        // Write DLL to temp file
        char tempPath[MAX_PATH];
        GetTempPathA(MAX_PATH, tempPath);
        std::string dllPath = std::string(tempPath) + "rls_" + std::to_string(GetTickCount()) + ".dll";
        
        std::ofstream tempFile(dllPath, std::ios::binary);
        if (!tempFile.is_open()) {
            UpdateStatus("Failed to create temp file!");
            CloseHandle(hProcess);
            return false;
        }
        
        tempFile.write((char*)dllData.data(), dllData.size());
        tempFile.close();
        
        // Allocate memory for DLL path
        LPVOID pRemotePath = VirtualAllocEx(hProcess, NULL, dllPath.size() + 1, 
                                           MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (!pRemotePath) {
            UpdateStatus("Failed to allocate memory!");
            CloseHandle(hProcess);
            return false;
        }
        
        // Write DLL path
        if (!WriteProcessMemory(hProcess, pRemotePath, dllPath.c_str(), 
                               dllPath.size() + 1, NULL)) {
            UpdateStatus("Failed to write DLL path!");
            VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
            CloseHandle(hProcess);
            return false;
        }
        
        // Get LoadLibraryA address
        HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
        LPVOID pLoadLibrary = (LPVOID)GetProcAddress(hKernel32, "LoadLibraryA");
        
        // Create remote thread
        HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, 
                                           (LPTHREAD_START_ROUTINE)pLoadLibrary,
                                           pRemotePath, 0, NULL);
        
        if (!hThread) {
            UpdateStatus("Failed to create remote thread!");
            VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
            CloseHandle(hProcess);
            return false;
        }
        
        WaitForSingleObject(hThread, INFINITE);
        
        // Cleanup
        VirtualFreeEx(hProcess, pRemotePath, 0, MEM_RELEASE);
        CloseHandle(hThread);
        CloseHandle(hProcess);
        
        // Delete temp file after delay
        std::thread([dllPath]() {
            Sleep(2000);
            DeleteFileA(dllPath.c_str());
        }).detach();
        
        return true;
    }
    
    
public:
    Loader(HWND hwnd) : hDlg(hwnd), heartbeatRunning(false), startTime(0) {
        hStatus = GetDlgItem(hwnd, IDC_STATUS);
        hInject = GetDlgItem(hwnd, IDC_INJECT);
        
        hwid = GetHWID();
        
        // Show HWID in title
        std::string title = "RELENTLESS - " + hwid;
        SetWindowTextA(hwnd, title.c_str());
        
        // Инициализация защиты
        InitFakeFlags();
        startTime = time(NULL);
        
        // Anti-Screenshot
        EnableAntiScreenshot();
        
        UpdateStatus("Ready");
    }
    
    ~Loader() {
        heartbeatRunning = false;
        if (heartbeatThread.joinable()) {
            heartbeatThread.join();
        }
    }
    
    void OnInject() {
        // Disable button
        EnableWindow(hInject, FALSE);
        SetWindowTextA(hInject, "LOADING...");
        
        // Фейковые проверки (обфускация)
        ObfuscatedCheck1();
        
        // Fake Flags check - ловушка для кракеров
        if (!CheckFakeFlags()) {
            UpdateStatus("Security violation!");
            SelfDestruct();
            return;
        }
        
        // Time Bomb - проверка системного времени
        if (!CheckSystemTime()) {
            UpdateStatus("System time invalid!");
            MessageBoxA(hDlg, "System time has been modified!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        // Integrity check - проверка что лоадер не пропатчен
        if (!CheckIntegrity()) {
            UpdateStatus("Loader modified!");
            MessageBoxA(hDlg, "Loader file has been modified!\n\nRedownload original loader.", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        ObfuscatedCheck2();
        
        // API Hook Detection
        if (DetectAPIHooks()) {
            UpdateStatus("API hooks detected!");
            MessageBoxA(hDlg, "API hooks detected!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        // Memory Scanning - поиск кряков
        if (ScanMemoryForCracks()) {
            UpdateStatus("Crack detected!");
            MessageBoxA(hDlg, "Crack or patch detected in memory!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        // Check for debugger/VM
        if (DetectDebugger()) {
            UpdateStatus("Debugger detected!");
            MessageBoxA(hDlg, "Debugger detected!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        if (DetectVM()) {
            UpdateStatus("VM/Sandbox detected!");
            MessageBoxA(hDlg, "VM or Sandbox detected!", "RELENTLESS", MB_OK | MB_ICONERROR);
            SelfDestruct();
            return;
        }
        
        // Детект программ записи (OBS, Bandicam и т.д.)
        if (DetectRecording()) {
            UpdateStatus("Recording software detected!");
            MessageBoxA(hDlg, "Please close screen recording software!", "RELENTLESS", MB_OK | MB_ICONWARNING);
            // Не делаем self-destruct, просто предупреждаем
        }
        
        // Get license from user
        char license[256] = {0};
        if (!GetDlgItemTextA(hDlg, IDC_LICENSE, license, sizeof(license)) || strlen(license) == 0) {
            UpdateStatus("Enter license key!");
            EnableWindow(hInject, TRUE);
            SetWindowTextA(hInject, "INJECT");
            MessageBoxA(hDlg, "Please enter your license key!", "RELENTLESS", MB_OK | MB_ICONWARNING);
            return;
        }
        
        // Authenticate with server
        if (!Authenticate(license)) {
            EnableWindow(hInject, TRUE);
            SetWindowTextA(hInject, "INJECT");
            MessageBoxA(hDlg, "Authentication failed!\n\nCheck your license key.", "RELENTLESS", MB_OK | MB_ICONERROR);
            return;
        }
        
        // Download DLL from server
        if (!DownloadDLL()) {
            EnableWindow(hInject, TRUE);
            SetWindowTextA(hInject, "INJECT");
            MessageBoxA(hDlg, "Failed to download cheat!\n\nCheck your connection.", "RELENTLESS", MB_OK | MB_ICONERROR);
            return;
        }
        
        // Find CS2
        UpdateStatus("Searching for CS2...");
        DWORD processId = FindCS2Process();
        
        if (processId == 0) {
            UpdateStatus("CS2 not found!");
            EnableWindow(hInject, TRUE);
            SetWindowTextA(hInject, "INJECT");
            MessageBoxA(hDlg, "CS2 not found!\n\nPlease start Counter-Strike 2.", "RELENTLESS", MB_OK | MB_ICONWARNING);
            return;
        }
        
        // Inject
        UpdateStatus("Injecting...");
        if (!InjectDLL(processId)) {
            EnableWindow(hInject, TRUE);
            SetWindowTextA(hInject, "INJECT");
            MessageBoxA(hDlg, "Injection failed!\n\nRun as administrator.", "RELENTLESS", MB_OK | MB_ICONERROR);
            return;
        }
        
        // Anti-Dump: Защищаем память после инжекта
        ProtectMemory();
        
        // Start heartbeat thread
        heartbeatRunning = true;
        heartbeatThread = std::thread(&Loader::HeartbeatLoop, this);
        
        UpdateStatus("Injected successfully!");
        SetWindowTextA(hInject, "INJECTED");
        
        MessageBoxA(hDlg, "Successfully injected!\n\nPress INSERT to open menu", "RELENTLESS", MB_OK | MB_ICONINFORMATION);
    }
};


static Loader* g_loader = nullptr;

INT_PTR CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_INITDIALOG:
            g_loader = new Loader(hwndDlg);
            return TRUE;
            
        case WM_COMMAND:
            if (LOWORD(wParam) == IDC_INJECT) {
                if (g_loader) {
                    g_loader->OnInject();
                }
                return TRUE;
            }
            if (LOWORD(wParam) == IDCANCEL) {
                EndDialog(hwndDlg, 0);
                return TRUE;
            }
            break;
            
        case WM_CLOSE:
            EndDialog(hwndDlg, 0);
            return TRUE;
    }
    
    return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Kill debuggers BEFORE showing GUI
    {
        const char* debuggers[] = {
            "x64dbg.exe", "x32dbg.exe", "ida.exe", "ida64.exe",
            "ollydbg.exe", "windbg.exe", "cheatengine-x86_64.exe",
            "processhacker.exe", "procexp.exe", "procexp64.exe",
            "dnspy.exe", "ghidra.exe", "idaq.exe", "idaq64.exe",
            "scylla_x64.exe", "scylla_x86.exe", "protection_id.exe",
            "lordpe.exe", "importrec.exe", "immunitydebugger.exe"
        };
        
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 entry;
            entry.dwSize = sizeof(PROCESSENTRY32);
            
            if (Process32First(snapshot, &entry)) {
                do {
                    for (const char* debugger : debuggers) {
                        if (_stricmp(entry.szExeFile, debugger) == 0) {
                            HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, entry.th32ProcessID);
                            if (hProcess) {
                                TerminateProcess(hProcess, 0);
                                CloseHandle(hProcess);
                            }
                        }
                    }
                } while (Process32Next(snapshot, &entry));
            }
            
            CloseHandle(snapshot);
        }
    }
    
    // Anti-debug check
    if (IsDebuggerPresent()) {
        ExitProcess(0);
    }
    
    InitCommonControls();
    
    DialogBoxA(hInstance, MAKEINTRESOURCEA(IDD_MAIN), NULL, DialogProc);
    
    if (g_loader) {
        delete g_loader;
    }
    
    return 0;
}
