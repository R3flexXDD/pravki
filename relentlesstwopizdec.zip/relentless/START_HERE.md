# 🚀 START HERE - Relentless Platform

## Быстрый старт за 3 шага:

### 1️⃣ Настрой Email (5 минут)

Открой `config.js` и измени:

```javascript
email: {
    enabled: true,
    auth: {
        user: 'your-email@gmail.com',     // ← Твой Gmail
        pass: 'xxxx xxxx xxxx xxxx'       // ← App Password
    }
}
```

**Как получить App Password:**
1. Зайди на https://myaccount.google.com/security
2. Включи 2FA
3. Найди "App passwords"
4. Создай пароль для "Mail"
5. Скопируй 16-значный код

**Или отключи email для теста:**
```javascript
email: {
    enabled: false  // ← Отключить
}
```

---

### 2️⃣ Настрой платежи (2 минуты)

В `config.js`:

```javascript
payment: {
    sbp: {
        phone: '+7 (900) 123-45-67'  // ← Твой номер
    },
    p2p: {
        card: '2200 1234 5678 9012'  // ← Твоя карта
    },
    crypto: {
        btc: 'bc1q...',  // ← BTC адрес
        eth: '0x...',    // ← ETH адрес
        usdt: 'T...'     // ← USDT адрес
    }
}
```

---

### 3️⃣ Запусти (1 команда)

```bash
npm start
```

Открой: http://localhost:3000

---

## ✅ Что работает прямо сейчас:

- ✅ Регистрация с email верификацией
- ✅ 2FA при логине
- ✅ Покупка подписок
- ✅ Автоматическое создание лицензий
- ✅ Лицензии в email и аккаунте
- ✅ История покупок
- ✅ Support система

---

## 🧪 Тестирование:

### С email (если настроил):
1. Зарегистрируйся → получи код на email
2. Войди → получи 2FA код
3. Купи подписку → получи лицензию на email
4. Зайди в аккаунт → скопируй ключ

### Без email (если отключил):
1. Зарегистрируйся (без кода)
2. Войди (без 2FA)
3. Купи подписку
4. Зайди в аккаунт → скопируй ключ

---

## 📖 Документация:

- **[QUICK_START.md](QUICK_START.md)** - Подробный быстрый старт
- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Полная инструкция
- **[PHP_API_INTEGRATION.md](PHP_API_INTEGRATION.md)** - Интеграция с loader
- **[FINAL_README.md](FINAL_README.md)** - Полная документация

---

## 🔧 Настройки безопасности:

В `config.js` можешь изменить:

```javascript
security: {
    loginAttempts: 5,              // Попыток логина
    twoFactorEnabled: true,        // Включить 2FA
    emailVerificationRequired: true // Обязательная верификация
}
```

---

## 🌐 Для продакшена:

1. Настрой HTTPS (Certbot)
2. Измени `sessionSecret` в config.js
3. Используй SendGrid вместо Gmail
4. Настрой PM2 для автозапуска
5. Установи PHP API (см. PHP_API_INTEGRATION.md)

---

## 🐛 Проблемы?

**Email не отправляется:**
- Проверь что `enabled: true`
- Для Gmail используй App Password
- Или отключи: `enabled: false`

**Сервер не запускается:**
- Проверь что `npm install` выполнен
- Проверь что config.js создан

**Лицензии не создаются:**
- Проверь `database/licenses.json`
- Проверь логи сервера

---

## 📊 Файлы базы данных:

Все в папке `database/`:
- `users.json` - пользователи
- `licenses.json` - лицензии
- `purchases.json` - покупки
- `subscriptions.json` - подписки
- `tickets.json` - тикеты
- `activity.json` - логи

---

## 🎯 Следующие шаги:

1. ✅ Запусти сайт
2. ✅ Протестируй покупку
3. ✅ Получи лицензионный ключ
4. 📖 Читай PHP_API_INTEGRATION.md для установки API
5. 🔧 Настрой loader с твоим доменом

---

**Все готово! Запускай и тестируй!** 🚀

```bash
npm start
```
