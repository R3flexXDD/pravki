const nodemailer = require('nodemailer');
const config = require('./config');

// Create transporter
let transporter = null;

if (config.email.enabled) {
    transporter = nodemailer.createTransport({
        host: config.email.host,
        port: config.email.port,
        secure: config.email.secure,
        auth: {
            user: config.email.auth.user,
            pass: config.email.auth.pass
        }
    });
}

// Email templates
const templates = {
    verification: function(code, name) {
        return {
            subject: 'Verify your email - Relentless',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a1a; color: #fff; padding: 20px; border-radius: 10px;">
                    <h1 style="color: #ff0000; text-align: center;">RELENTLESS</h1>
                    <h2 style="color: #fff;">Email Verification</h2>
                    <p>Hi ${name},</p>
                    <p>Thank you for registering! Please verify your email address by entering this code:</p>
                    <div style="background: #2a2a2a; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
                        <h1 style="color: #ff0000; font-size: 36px; letter-spacing: 5px; margin: 0;">${code}</h1>
                    </div>
                    <p>This code will expire in 24 hours.</p>
                    <p style="color: #888; font-size: 12px; margin-top: 30px;">If you didn't create an account, please ignore this email.</p>
                    <hr style="border: 1px solid #333; margin: 20px 0;">
                    <p style="text-align: center; color: #888; font-size: 12px;">© 2026 0x5team. All rights reserved.</p>
                </div>
            `
        };
    },
    
    twoFactor: function(code, name) {
        return {
            subject: 'Your 2FA Code - Relentless',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a1a; color: #fff; padding: 20px; border-radius: 10px;">
                    <h1 style="color: #ff0000; text-align: center;">RELENTLESS</h1>
                    <h2 style="color: #fff;">Two-Factor Authentication</h2>
                    <p>Hi ${name},</p>
                    <p>Your 2FA code for login:</p>
                    <div style="background: #2a2a2a; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
                        <h1 style="color: #ff0000; font-size: 36px; letter-spacing: 5px; margin: 0;">${code}</h1>
                    </div>
                    <p>This code will expire in 5 minutes.</p>
                    <p style="color: #888; font-size: 12px; margin-top: 30px;">If you didn't try to login, please secure your account immediately.</p>
                    <hr style="border: 1px solid #333; margin: 20px 0;">
                    <p style="text-align: center; color: #888; font-size: 12px;">© 2026 0x5team. All rights reserved.</p>
                </div>
            `
        };
    },
    
    purchaseConfirmation: function(name, plan, price, expiresAt, licenseKey) {
        return {
            subject: 'Purchase Confirmed - Relentless',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #1a1a1a; color: #fff; padding: 20px; border-radius: 10px;">
                    <h1 style="color: #ff0000; text-align: center;">RELENTLESS</h1>
                    <h2 style="color: #fff;">Purchase Confirmed!</h2>
                    <p>Hi ${name},</p>
                    <p>Your subscription has been activated:</p>
                    <div style="background: #2a2a2a; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <p><strong>Plan:</strong> ${plan}</p>
                        <p><strong>Price:</strong> ${price}</p>
                        <p><strong>Expires:</strong> ${new Date(expiresAt).toLocaleDateString()}</p>
                    </div>
                    <div style="background: #ff0000; background: linear-gradient(135deg, #ff0000 0%, #cc0000 100%); padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
                        <h3 style="margin: 0 0 10px 0; color: #fff;">Your License Key</h3>
                        <div style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 6px; font-family: 'Courier New', monospace; font-size: 20px; letter-spacing: 2px; font-weight: bold;">
                            ${licenseKey}
                        </div>
                        <p style="margin: 10px 0 0 0; font-size: 12px; color: #ffcccc;">Copy this key to use in the loader</p>
                    </div>
                    <p><strong>How to use:</strong></p>
                    <ol style="color: #a1a1a6; line-height: 1.8;">
                        <li>Download the loader from your account page</li>
                        <li>Run the loader</li>
                        <li>Enter your license key: <strong style="color: #ff0000;">${licenseKey}</strong></li>
                        <li>Enjoy!</li>
                    </ol>
                    <div style="background: rgba(255, 69, 58, 0.2); border: 1px solid rgba(255, 69, 58, 0.5); padding: 15px; border-radius: 8px; margin: 20px 0;">
                        <strong style="color: #ff453a;">Important:</strong>
                        <ul style="margin: 10px 0 0 0; color: #ffcccc;">
                            <li>Keep your license key safe</li>
                            <li>Do not share it with anyone</li>
                            <li>License is bound to your HWID on first use</li>
                        </ul>
                    </div>
                    <hr style="border: 1px solid #333; margin: 20px 0;">
                    <p style="text-align: center; color: #888; font-size: 12px;">© 2026 0x5team. All rights reserved.</p>
                </div>
            `
        };
    }
};

// Send email function
async function sendEmail(to, template, ...args) {
    if (!config.email.enabled || !transporter) {
        console.log('📧 Email disabled - would send to:', to);
        return { success: true, message: 'Email disabled' };
    }

    try {
        const emailContent = templates[template](...args);
        
        await transporter.sendMail({
            from: config.email.from,
            to: to,
            subject: emailContent.subject,
            html: emailContent.html
        });

        console.log('✅ Email sent to:', to);
        return { success: true };
    } catch (error) {
        console.error('❌ Email error:', error);
        return { success: false, error: error.message };
    }
}

module.exports = {
    sendVerificationEmail: function(to, code, name) {
        return sendEmail(to, 'verification', code, name);
    },
    
    send2FAEmail: function(to, code, name) {
        return sendEmail(to, 'twoFactor', code, name);
    },
    
    sendPurchaseEmail: function(to, name, plan, price, expiresAt, licenseKey) {
        return sendEmail(to, 'purchaseConfirmation', name, plan, price, expiresAt, licenseKey);
    }
};
