# 🚀 Quick Start - Relentless

## Минимальная настройка (5 минут)

### 1. Установка
```bash
npm install
```

### 2. Настройка Email (Gmail)

Открой `config.js` и измени:
```javascript
email: {
    enabled: true,
    auth: {
        user: 'your-email@gmail.com', // Твой Gmail
        pass: 'xxxx xxxx xxxx xxxx' // App Password из Google
    }
}
```

Как получить App Password:
1. https://myaccount.google.com/security
2. Включи 2FA
3. "App passwords" → "Mail" → Скопируй пароль

### 3. Настройка платежей

В `config.js`:
```javascript
payment: {
    sbp: { phone: '+7 (900) 123-45-67' },
    p2p: { card: '2200 1234 5678 9012' },
    crypto: {
        btc: 'твой BTC адрес',
        eth: 'твой ETH адрес',
        usdt: 'твой USDT адрес'
    }
}
```

### 4. Запуск
```bash
npm start
```

Готово! Открой http://localhost:3000

---

## Тестирование

1. Зарегистрируйся с реальным email
2. Проверь почту → введи код верификации
3. Войди → проверь почту → введи 2FA код
4. Купи подписку → проверь email подтверждение
5. Зайди в аккаунт → посмотри историю покупок

---

## Отключить Email (для теста)

В `config.js`:
```javascript
email: {
    enabled: false // Отключить email
}
```

При отключенном email:
- Нет верификации
- Нет 2FA
- Можно сразу логиниться

---

## Что реализовано из website_fixes.txt:

✅ Email верификация
✅ 2FA через email
✅ Rate limiting (защита от брутфорса)
✅ История покупок
✅ Email уведомления
✅ Логирование активности
✅ Безопасное хранение паролей (bcrypt)
✅ Минимум 8 символов пароль
✅ JSON база данных (работает везде)

---

## Для продакшена:

1. Настрой HTTPS
2. Измени `sessionSecret` в config.js
3. Используй SendGrid/Mailgun вместо Gmail
4. Настрой PM2 для автозапуска
5. Добавь backup базы данных

Подробнее в `SETUP_GUIDE.md`
