# Loader API Documentation

## Base URL
```
http://your-domain.com/loader
```

---

## 1. Authentication (Login)

**Endpoint:** `POST /loader/auth`

**Description:** Validates license key and binds HWID on first use.

**Request Body:**
```json
{
    "license": "XXXX-XXXX-XXXX-XXXX",
    "hwid": "hardware_id_string"
}
```

**Success Response:**
```json
{
    "success": true,
    "message": "Authentication successful",
    "data": {
        "plan": "External 1 Month",
        "type": "External",
        "expires_at": "2026-05-15T12:00:00.000Z"
    }
}
```

**Error Response:**
```json
{
    "success": false,
    "message": "Invalid license key"
}
```

**Error Messages:**
- `Invalid request` - Missing license or hwid
- `Invalid license key` - License not found
- `License expired` - License has expired
- `License deactivated` - License was banned/deactivated
- `HWID mismatch` - License bound to different HWID

---

## 2. Heartbeat (Keep Alive)

**Endpoint:** `POST /loader/heartbeat`

**Description:** Keeps session alive, call every 60 seconds.

**Request Body:**
```json
{
    "license": "XXXX-XXXX-XXXX-XXXX",
    "hwid": "hardware_id_string"
}
```

**Success Response:**
```json
{
    "success": true
}
```

**Error Response:**
```json
{
    "success": false
}
```

---

## 3. Check Ban Status

**Endpoint:** `POST /loader/ban`

**Description:** Check if license is banned/deactivated.

**Request Body:**
```json
{
    "license": "XXXX-XXXX-XXXX-XXXX"
}
```

**Response:**
```json
{
    "banned": false,
    "reason": null
}
```

Or if banned:
```json
{
    "banned": true,
    "reason": "License deactivated"
}
```

---

## 4. Download Cheat File

**Endpoint:** `GET /loader/download?license=XXXX-XXXX-XXXX-XXXX`

**Description:** Get download URL for cheat DLL.

**Success Response:**
```json
{
    "success": true,
    "download_url": "https://your-cdn.com/relentless.dll",
    "version": "1.0.0"
}
```

**Error Response:**
```json
{
    "error": "Invalid license"
}
```

---

## 5. License Info

**Endpoint:** `GET /loader/info?license=XXXX-XXXX-XXXX-XXXX`

**Description:** Get license information.

**Success Response:**
```json
{
    "success": true,
    "license": {
        "key": "XXXX-XXXX-XXXX-XXXX",
        "plan": "External 1 Month",
        "type": "External",
        "active": true,
        "expires_at": "2026-05-15T12:00:00.000Z",
        "hwid_bound": true
    }
}
```

---

## C++ Loader Integration Example

```cpp
#include <curl/curl.h>
#include <json/json.h>

std::string SERVER_URL = "http://your-domain.com/loader";

bool AuthenticateLoader(std::string license, std::string hwid) {
    CURL* curl = curl_easy_init();
    if (!curl) return false;

    // Prepare JSON
    Json::Value json;
    json["license"] = license;
    json["hwid"] = hwid;
    
    Json::StreamWriterBuilder writer;
    std::string jsonStr = Json::writeString(writer, json);

    // Set URL
    std::string url = SERVER_URL + "/auth";
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    
    // Set POST data
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonStr.c_str());
    
    // Set headers
    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    
    // Response buffer
    std::string response;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    
    // Perform request
    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    
    if (res != CURLE_OK) return false;
    
    // Parse response
    Json::Value root;
    Json::CharReaderBuilder reader;
    std::istringstream stream(response);
    std::string errs;
    
    if (!Json::parseFromStream(reader, stream, &root, &errs)) {
        return false;
    }
    
    return root["success"].asBool();
}

void HeartbeatThread(std::string license, std::string hwid) {
    while (true) {
        CURL* curl = curl_easy_init();
        if (curl) {
            Json::Value json;
            json["license"] = license;
            json["hwid"] = hwid;
            
            Json::StreamWriterBuilder writer;
            std::string jsonStr = Json::writeString(writer, json);
            
            std::string url = SERVER_URL + "/heartbeat";
            curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonStr.c_str());
            
            struct curl_slist* headers = NULL;
            headers = curl_slist_append(headers, "Content-Type: application/json");
            curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
            
            std::string response;
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
            
            CURLcode res = curl_easy_perform(curl);
            curl_easy_cleanup(curl);
            
            // Parse response
            Json::Value root;
            Json::CharReaderBuilder reader;
            std::istringstream stream(response);
            std::string errs;
            
            if (Json::parseFromStream(reader, stream, &root, &errs)) {
                if (!root["success"].asBool()) {
                    // License invalid, exit cheat
                    ExitProcess(0);
                }
            }
        }
        
        Sleep(60000); // 60 seconds
    }
}
```

---

## Testing with cURL

### Test Auth:
```bash
curl -X POST http://localhost:3000/loader/auth \
  -H "Content-Type: application/json" \
  -d '{"license":"XXXX-XXXX-XXXX-XXXX","hwid":"test-hwid-123"}'
```

### Test Heartbeat:
```bash
curl -X POST http://localhost:3000/loader/heartbeat \
  -H "Content-Type: application/json" \
  -d '{"license":"XXXX-XXXX-XXXX-XXXX","hwid":"test-hwid-123"}'
```

### Test Ban Check:
```bash
curl -X POST http://localhost:3000/loader/ban \
  -H "Content-Type: application/json" \
  -d '{"license":"XXXX-XXXX-XXXX-XXXX"}'
```

### Test Info:
```bash
curl http://localhost:3000/loader/info?license=XXXX-XXXX-XXXX-XXXX
```

---

## Security Notes

1. **HTTPS Required:** Use HTTPS in production to encrypt license keys
2. **Rate Limiting:** Already implemented in server.js
3. **HWID Binding:** License binds to first HWID used
4. **Heartbeat:** Call every 60 seconds to detect license revocation
5. **Obfuscation:** Obfuscate your loader to protect API endpoints

---

## Available Endpoints Summary

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /loader/auth | Authenticate license + bind HWID |
| POST | /loader/heartbeat | Keep session alive |
| POST | /loader/ban | Check ban status |
| GET | /loader/download | Download cheat file |
| GET | /loader/info | Get license info |

---

## Response Codes

- `200` - Success
- `400` - Bad request (missing parameters)
- `403` - Forbidden (invalid/expired license)
- `404` - Not found (license doesn't exist)
- `500` - Server error
