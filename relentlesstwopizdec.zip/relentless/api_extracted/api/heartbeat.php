<?php
// RELENTLESS Heartbeat API
// Kablykteam © 2026

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

// Database configuration
$db_host = 'localhost';
$db_user = 'your_db_user';
$db_pass = 'your_db_pass';
$db_name = 'relentless';

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("ERROR");
}

// Get POST data
$token = isset($_POST['token']) ? $conn->real_escape_string($_POST['token']) : '';

if (empty($token)) {
    die("ERROR");
}

// Validate session token
$stmt = $conn->prepare("SELECT id, license_id, hwid FROM sessions WHERE token = ? AND expires_at > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmt->close();
    $conn->close();
    die("INVALID");
}

$row = $result->fetch_assoc();
$session_id = $row['id'];
$license_id = $row['license_id'];
$hwid = $row['hwid'];

$stmt->close();

// Check if HWID is banned
$stmt = $conn->prepare("SELECT id FROM banned_hwids WHERE hwid = ?");
$stmt->bind_param("s", $hwid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Ban detected - invalidate session
    $stmt->close();
    
    $stmt = $conn->prepare("DELETE FROM sessions WHERE id = ?");
    $stmt->bind_param("i", $session_id);
    $stmt->execute();
    $stmt->close();
    
    $conn->close();
    die("BANNED");
}
$stmt->close();

// Check if license is still active
$stmt = $conn->prepare("SELECT active, expires_at FROM licenses WHERE id = ?");
$stmt->bind_param("i", $license_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmt->close();
    $conn->close();
    die("INVALID");
}

$row = $result->fetch_assoc();
$active = $row['active'];
$expires_at = $row['expires_at'];

$stmt->close();

if (!$active || strtotime($expires_at) < time()) {
    $conn->close();
    die("EXPIRED");
}

// Update session last activity
$stmt = $conn->prepare("UPDATE sessions SET last_activity = NOW() WHERE id = ?");
$stmt->bind_param("i", $session_id);
$stmt->execute();
$stmt->close();

// Log heartbeat
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $conn->prepare("INSERT INTO heartbeat_logs (session_id, license_id, hwid, ip) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $session_id, $license_id, $hwid, $ip);
$stmt->execute();
$stmt->close();

$conn->close();

echo "OK";
?>
