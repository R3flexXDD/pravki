-- RELENTLESS Database Schema
-- Kablykteam © 2026

CREATE DATABASE IF NOT EXISTS relentless;
USE relentless;

-- Licenses table
CREATE TABLE IF NOT EXISTS licenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_key VARCHAR(64) UNIQUE NOT NULL,
    hwid VARCHAR(64) DEFAULT NULL,
    active TINYINT(1) DEFAULT 1,
    expires_at DATETIME NOT NULL,
    max_sessions INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_license_key (license_key),
    INDEX idx_hwid (hwid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sessions table
CREATE TABLE IF NOT EXISTS sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_id INT NOT NULL,
    hwid VARCHAR(64) NOT NULL,
    token VARCHAR(128) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_license_id (license_id),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Banned HWIDs table
CREATE TABLE IF NOT EXISTS banned_hwids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hwid VARCHAR(64) UNIQUE NOT NULL,
    reason TEXT,
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hwid (hwid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Authentication logs
CREATE TABLE IF NOT EXISTS auth_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_id INT,
    hwid VARCHAR(64),
    ip VARCHAR(45),
    success TINYINT(1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_license_id (license_id),
    INDEX idx_hwid (hwid),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Download logs
CREATE TABLE IF NOT EXISTS download_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT,
    license_id INT,
    hwid VARCHAR(64),
    ip VARCHAR(45),
    mutation_size INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_license_id (license_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Heartbeat logs
CREATE TABLE IF NOT EXISTS heartbeat_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT,
    license_id INT,
    hwid VARCHAR(64),
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_id (session_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ban logs
CREATE TABLE IF NOT EXISTS ban_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hwid VARCHAR(64),
    reason TEXT,
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hwid (hwid),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Example: Insert test license (expires in 30 days)
-- INSERT INTO licenses (license_key, expires_at, max_sessions) 
-- VALUES ('TEST-1234-5678-ABCD', DATE_ADD(NOW(), INTERVAL 30 DAY), 1);

-- Example: Ban a HWID
-- INSERT INTO banned_hwids (hwid, reason) 
-- VALUES ('abc123def456', 'Detected crack attempt');
