<?php
// RELENTLESS DLL Download API with Code Mutation
// Kablykteam © 2026

header('Content-Type: application/octet-stream');
header('Access-Control-Allow-Origin: *');

// Database configuration
$db_host = 'localhost';
$db_user = 'your_db_user';
$db_pass = 'your_db_pass';
$db_name = 'relentless';

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("ERROR");
}

// Get POST data
$token = isset($_POST['token']) ? $conn->real_escape_string($_POST['token']) : '';

if (empty($token)) {
    die("ERROR");
}

// Validate session token
$stmt = $conn->prepare("SELECT id, license_id, hwid FROM sessions WHERE token = ? AND expires_at > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmt->close();
    $conn->close();
    die("ERROR");
}

$row = $result->fetch_assoc();
$session_id = $row['id'];
$license_id = $row['license_id'];
$hwid = $row['hwid'];

$stmt->close();

// Check if HWID is banned (double check)
$stmt = $conn->prepare("SELECT id FROM banned_hwids WHERE hwid = ?");
$stmt->bind_param("s", $hwid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $stmt->close();
    $conn->close();
    die("BANNED");
}
$stmt->close();

// Path to original DLL
$dll_path = '/path/to/relentless.dll';

if (!file_exists($dll_path)) {
    $conn->close();
    die("ERROR");
}

// Read DLL
$dll_data = file_get_contents($dll_path);

// CODE MUTATION: Add random bytes at the end (polymorphic signature)
// This makes each download unique to bypass signature detection
$mutation_size = rand(1024, 4096);
$mutation_data = random_bytes($mutation_size);
$dll_data .= $mutation_data;

// Encrypt DLL with session token (XOR encryption)
$encrypted = '';
$token_len = strlen($token);
$data_len = strlen($dll_data);

for ($i = 0; $i < $data_len; $i++) {
    $encrypted .= chr(ord($dll_data[$i]) ^ ord($token[$i % $token_len]));
}

// Log download
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $conn->prepare("INSERT INTO download_logs (session_id, license_id, hwid, ip, mutation_size) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iissi", $session_id, $license_id, $hwid, $ip, $mutation_size);
$stmt->execute();
$stmt->close();

// Update session last activity
$stmt = $conn->prepare("UPDATE sessions SET last_activity = NOW() WHERE id = ?");
$stmt->bind_param("i", $session_id);
$stmt->execute();
$stmt->close();

$conn->close();

// Send encrypted DLL
echo $encrypted;
?>
