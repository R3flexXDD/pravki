<?php
// RELENTLESS Ban API
// Kablykteam © 2026

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

// Database configuration
$db_host = 'localhost';
$db_user = 'your_db_user';
$db_pass = 'your_db_pass';
$db_name = 'relentless';

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("ERROR");
}

// Get POST data
$hwid = isset($_POST['hwid']) ? $conn->real_escape_string($_POST['hwid']) : '';
$reason = isset($_POST['reason']) ? $conn->real_escape_string($_POST['reason']) : 'Unknown';

if (empty($hwid)) {
    die("ERROR");
}

// Check if already banned
$stmt = $conn->prepare("SELECT id FROM banned_hwids WHERE hwid = ?");
$stmt->bind_param("s", $hwid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Already banned
    $stmt->close();
    $conn->close();
    echo "ALREADY_BANNED";
    exit;
}
$stmt->close();

// Add to ban list
$stmt = $conn->prepare("INSERT INTO banned_hwids (hwid, reason) VALUES (?, ?)");
$stmt->bind_param("ss", $hwid, $reason);
$stmt->execute();
$stmt->close();

// Invalidate all sessions for this HWID
$stmt = $conn->prepare("DELETE FROM sessions WHERE hwid = ?");
$stmt->bind_param("s", $hwid);
$stmt->execute();
$stmt->close();

// Log ban
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $conn->prepare("INSERT INTO ban_logs (hwid, reason, ip) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $hwid, $reason, $ip);
$stmt->execute();
$stmt->close();

$conn->close();

echo "BANNED";
?>
