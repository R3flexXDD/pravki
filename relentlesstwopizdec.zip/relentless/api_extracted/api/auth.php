<?php
// RELENTLESS Authentication API
// Kablykteam © 2026

header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

// Database configuration
$db_host = 'localhost';
$db_user = 'your_db_user';
$db_pass = 'your_db_pass';
$db_name = 'relentless';

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("ERROR:Database connection failed");
}

// Get POST data
$hwid = isset($_POST['hwid']) ? $conn->real_escape_string($_POST['hwid']) : '';
$license = isset($_POST['license']) ? $conn->real_escape_string($_POST['license']) : '';

if (empty($hwid) || empty($license)) {
    die("ERROR:Missing parameters");
}

// Check if HWID is banned
$stmt = $conn->prepare("SELECT id FROM banned_hwids WHERE hwid = ?");
$stmt->bind_param("s", $hwid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $stmt->close();
    $conn->close();
    die("BANNED:Your HWID is banned");
}
$stmt->close();

// Check license validity
$stmt = $conn->prepare("SELECT id, hwid, expires_at, max_sessions FROM licenses WHERE license_key = ? AND active = 1");
$stmt->bind_param("s", $license);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmt->close();
    $conn->close();
    die("ERROR:Invalid license key");
}

$row = $result->fetch_assoc();
$license_id = $row['id'];
$bound_hwid = $row['hwid'];
$expires_at = $row['expires_at'];
$max_sessions = $row['max_sessions'];

$stmt->close();

// Check if license expired
if (strtotime($expires_at) < time()) {
    $conn->close();
    die("ERROR:License expired");
}

// Check HWID binding
if (!empty($bound_hwid) && $bound_hwid !== $hwid) {
    $conn->close();
    die("ERROR:License bound to different HWID");
}

// Bind HWID if not bound
if (empty($bound_hwid)) {
    $stmt = $conn->prepare("UPDATE licenses SET hwid = ? WHERE id = ?");
    $stmt->bind_param("si", $hwid, $license_id);
    $stmt->execute();
    $stmt->close();
}

// Check active sessions
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM sessions WHERE license_id = ? AND expires_at > NOW()");
$stmt->bind_param("i", $license_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$active_sessions = $row['count'];
$stmt->close();

if ($active_sessions >= $max_sessions) {
    $conn->close();
    die("ERROR:Maximum sessions reached");
}

// Generate session token
$session_token = bin2hex(random_bytes(32));
$expires_at = date('Y-m-d H:i:s', time() + 86400); // 24 hours

// Create session
$stmt = $conn->prepare("INSERT INTO sessions (license_id, hwid, token, expires_at) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isss", $license_id, $hwid, $session_token, $expires_at);
$stmt->execute();
$stmt->close();

// Log authentication
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $conn->prepare("INSERT INTO auth_logs (license_id, hwid, ip, success) VALUES (?, ?, ?, 1)");
$stmt->bind_param("iss", $license_id, $hwid, $ip);
$stmt->execute();
$stmt->close();

$conn->close();

echo "SUCCESS:" . $session_token;
?>
