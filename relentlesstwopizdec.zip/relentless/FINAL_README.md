# 🎮 RELENTLESS - Complete CS:GO Cheat Platform
**Full-Stack Solution: Website + API + Loader**

**Kablykteam © 2026**

---

## 🌟 Что это?

Полная платформа для продажи и управления CS:GO читом:
- **Website** (Node.js) - регистрация, покупка, управление лицензиями
- **PHP API** - авторизация loader'а, проверка лицензий
- **Loader** (C++) - клиент для пользователей

---

## ✨ Возможности

### Website (Node.js)
- ✅ Email верификация (обязательная)
- ✅ 2FA через email
- ✅ Безопасная регистрация (bcrypt)
- ✅ Покупка подписок (External/Internal)
- ✅ Автоматическое создание лицензий
- ✅ Управление лицензиями (копирование, сброс HWID)
- ✅ История покупок
- ✅ Support система
- ✅ Email уведомления

### PHP API
- ✅ Авторизация по лицензии + HWID
- ✅ Проверка бана
- ✅ Загрузка DLL с мутацией кода
- ✅ Heartbeat система (30 сек)
- ✅ Логирование всех действий
- ✅ MySQL база данных

### Loader (C++)
- ✅ HTTPS защита
- ✅ Anti-debug
- ✅ HWID привязка
- ✅ Автоматическая загрузка DLL
- ✅ Heartbeat проверка

---

## 🚀 Быстрый старт

### 1. Website

```bash
# Установка
npm install

# Настройка
cp config.example.js config.js
nano config.js  # Настрой email и платежи

# Запуск
npm start
```

Открой http://localhost:3000

### 2. PHP API

```bash
# Загрузи файлы на сервер
scp api_extracted/api/*.php user@server:/var/www/html/api/

# Настрой MySQL
mysql -u root -p < api_extracted/api/database.sql

# Настрой подключение в PHP файлах
nano /var/www/html/api/auth.php  # Измени $db_user, $db_pass

# Настрой HTTPS
certbot --apache -d your-domain.com
```

### 3. Loader

```cpp
// В loader.cpp измени:
#define SERVER_URL "https://your-domain.com/api"

// Перекомпилируй
```

---

## 📖 Документация

- **[README.md](README.md)** - Основная документация website
- **[QUICK_START.md](QUICK_START.md)** - Быстрый старт за 5 минут
- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Полная инструкция по настройке
- **[PHP_API_INTEGRATION.md](PHP_API_INTEGRATION.md)** - Интеграция PHP API и Loader
- **[CHECKLIST.md](CHECKLIST.md)** - Список выполненных задач
- **[DONE.txt](DONE.txt)** - Финальный отчет

---

## 🔄 Как работает система

```
┌─────────────┐
│   Website   │ ← Пользователь регистрируется
│  (Node.js)  │ ← Покупает подписку
└──────┬──────┘
       │
       ├─→ Создает лицензию (XXXX-XXXX-XXXX-XXXX)
       ├─→ Отправляет на email
       └─→ Сохраняет в database/licenses.json
       
       ↓ Синхронизация (cron или webhook)
       
┌─────────────┐
│   PHP API   │ ← Лицензии в MySQL
│   (MySQL)   │ ← Проверка при авторизации
└──────┬──────┘
       │
       ├─→ auth.php - проверяет лицензию + HWID
       ├─→ download.php - отдает DLL
       └─→ heartbeat.php - проверяет сессию
       
       ↓
       
┌─────────────┐
│   Loader    │ ← Пользователь вводит ключ
│    (C++)    │ ← Авторизуется через PHP API
└─────────────┘ ← Скачивает и запускает DLL
```

---

## 💳 Тарифы

### External
- 7 Days - $2.49
- 1 Month - $19.99
- 3 Months - $49.99
- 6 Months - $89.99

### Internal
- 7 Days - $6.23
- 1 Month - $39.98
- 3 Months - $99.98
- 6 Months - $179.98

---

## 📁 Структура проекта

```
relentless/
├── server.js              # Главный сервер
├── config.js              # Настройки (создай из config.example.js)
├── emailService.js        # Email сервис
├── licenseAPI.js          # Управление лицензиями
├── package.json           # Зависимости
│
├── database/              # JSON база (auto-created)
│   ├── users.json
│   ├── subscriptions.json
│   ├── purchases.json
│   ├── licenses.json      # Лицензии
│   ├── tickets.json
│   └── activity.json
│
├── public/                # Frontend
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── main.js
│       └── auth.js
│
├── api_extracted/         # PHP API
│   └── api/
│       ├── auth.php       # Авторизация
│       ├── download.php   # Загрузка DLL
│       ├── heartbeat.php  # Проверка сессии
│       ├── ban.php        # Бан система
│       └── database.sql   # MySQL схема
│
├── loader_extracted/      # C++ Loader
│   └── loader/
│       ├── loader.cpp
│       ├── https_protection.h
│       └── resource.*
│
└── docs/                  # Документация
    ├── README.md
    ├── QUICK_START.md
    ├── SETUP_GUIDE.md
    ├── PHP_API_INTEGRATION.md
    ├── CHECKLIST.md
    └── DONE.txt
```

---

## 🔒 Безопасность

### Website
- Bcrypt хеширование паролей (10 rounds)
- Email верификация (обязательная)
- 2FA через email (включена по умолчанию)
- Rate limiting (5 попыток / 15 минут)
- Сессии истекают через 24 часа
- Логирование всех действий

### PHP API
- HTTPS обязателен
- Проверка бана по HWID
- Session tokens (64 символа)
- Heartbeat каждые 30 секунд
- Логирование auth/download/heartbeat

### Loader
- Anti-debug защита
- HWID привязка
- Code mutation (уникальный DLL каждый раз)
- Self-destruct при обнаружении VM

---

## 🧪 Тестирование

### 1. Website
```bash
1. Зарегистрируйся → получи код на email
2. Войди → получи 2FA код на email
3. Купи подписку → получи лицензию на email
4. Зайди в аккаунт → посмотри лицензии
5. Скопируй ключ
```

### 2. PHP API
```bash
curl -X POST https://your-domain.com/api/auth.php \
  -d "hwid=test123&license=YOUR-KEY"
# Должен вернуть: SUCCESS:token
```

### 3. Loader
```bash
1. Запусти loader
2. Введи лицензионный ключ
3. Loader авторизуется и скачает DLL
```

---

## 🛠️ Управление

### Создать лицензию вручную (MySQL)
```sql
INSERT INTO licenses (license_key, expires_at, max_sessions) 
VALUES ('XXXX-XXXX-XXXX-XXXX', DATE_ADD(NOW(), INTERVAL 30 DAY), 1);
```

### Забанить HWID
```sql
INSERT INTO banned_hwids (hwid, reason) 
VALUES ('abc123def456', 'Crack attempt');
```

### Деактивировать лицензию
```sql
UPDATE licenses SET active = 0 WHERE license_key = 'XXXX-XXXX-XXXX-XXXX';
```

### Сбросить HWID (через website)
- Зайди в аккаунт
- Найди лицензию
- Нажми "Reset HWID"

---

## 📊 Мониторинг

### Website (JSON)
```bash
cat database/licenses.json
cat database/purchases.json
cat database/activity.json
```

### PHP API (MySQL)
```sql
-- Активные лицензии
SELECT * FROM licenses WHERE active = 1 AND expires_at > NOW();

-- Активные сессии
SELECT s.*, l.license_key 
FROM sessions s 
JOIN licenses l ON s.license_id = l.id 
WHERE s.expires_at > NOW();

-- Последние авторизации
SELECT * FROM auth_logs ORDER BY created_at DESC LIMIT 50;
```

---

## 🌐 Production Deployment

### 1. Website
```bash
# PM2 для автозапуска
npm install -g pm2
pm2 start server.js --name relentless
pm2 save
pm2 startup
```

### 2. PHP API
```bash
# HTTPS обязателен
certbot --apache -d your-domain.com

# Nginx reverse proxy
nano /etc/nginx/sites-available/relentless
```

### 3. Синхронизация лицензий
```bash
# Cron каждые 5 минут
*/5 * * * * cd /path/to/website && node sync_licenses.js
```

---

## 🐛 Troubleshooting

### Website
- Email не отправляется → проверь config.js
- 2FA не работает → проверь что email включен
- Rate limiting блокирует → подожди 15 минут

### PHP API
- Connection failed → проверь HTTPS
- Invalid license → проверь MySQL
- Download failed → проверь путь к DLL

### Loader
- Auth failed → проверь лицензию в MySQL
- HWID banned → проверь banned_hwids
- Download failed → проверь download.php

---

## 📞 Support

Если что-то не работает:
1. Проверь логи сервера
2. Проверь database/activity.json
3. Проверь MySQL логи
4. Читай документацию

---

## 📄 License

ISC License - © 2026 0x5team

---

## 🎉 Credits

**Kablykteam © 2026**

Built with:
- Node.js + Express
- Nodemailer
- Bcrypt
- Express Rate Limit
- PHP + MySQL
- C++ (Loader)

---

## ✅ Status

**✅ ПОЛНОСТЬЮ ГОТОВО К ИСПОЛЬЗОВАНИЮ!**

- Website: ✅ Работает
- PHP API: ✅ Готов к установке
- Loader: ✅ Готов к компиляции
- Документация: ✅ Написана
- Интеграция: ✅ Настроена

**Все задачи из website_fixes.txt выполнены!**
**Интеграция с API и Loader завершена!**

---

**Ready to deploy!** 🚀
