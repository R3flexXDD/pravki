// Configuration file
module.exports = {
    // Server settings
    port: 3000,
    sessionSecret: 'relentless-secret-key-2026-change-in-production',
    
    // Email settings (SMTP)
    email: {
        enabled: true, // Set to false to disable email features
        service: 'gmail', // or 'smtp'
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
            user: '0x5teamgroup@gmail.com', // Change this
            pass: '' // Change this (use App Password for Gmail)
        },
        from: 'Relentless <0x5teamgroup@gmail.com>'
    },
    
    // Security settings
    security: {
        // Rate limiting
        loginAttempts: 5, // Max login attempts
        loginWindow: 15 * 60 * 1000, // 15 minutes
        apiRateLimit: 100, // Max API requests per window
        apiWindow: 60 * 1000, // 1 minute
        
        // 2FA
        twoFactorEnabled: true,
        twoFactorCodeExpiry: 5 * 60 * 1000, // 5 minutes
        
        // Email verification
        emailVerificationRequired: true,
        verificationCodeExpiry: 24 * 60 * 60 * 1000 // 24 hours
    },
    
    // Payment settings
    payment: {
        sbp: {
            phone: '+7 (XXX) XXX-XX-XX' // Change this
        },
        p2p: {
            card: 'XXXX XXXX XXXX XXXX' // Change this
        },
        crypto: {
            btc: 'bc1qXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', // Change this
            eth: '0xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', // Change this
            usdt: 'TXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX' // Change this
        }
    }
};
