# RELENTLESS - CS:GO Enhancement Platform

**Secure subscription-based platform with email verification, 2FA, and payment processing**

![Version](https://img.shields.io/badge/version-2.0.0-red)
![Node](https://img.shields.io/badge/node-%3E%3D10.0.0-green)
![License](https://img.shields.io/badge/license-ISC-blue)

---

## ✨ Features

### Security
- ✅ Email verification (mandatory)
- ✅ Two-factor authentication (2FA via email)
- ✅ Rate limiting (brute-force protection)
- ✅ Bcrypt password hashing (10 rounds)
- ✅ Session management (24h expiry)
- ✅ Activity logging

### Functionality
- ✅ User registration & authentication
- ✅ Subscription management (External & Internal)
- ✅ Purchase history
- ✅ Support ticket system
- ✅ Email notifications
- ✅ Automatic subscription expiration

### Payments
- ✅ SBP (Russian payment system)
- ✅ P2P Card transfers
- ✅ Cryptocurrency (BTC, ETH, USDT)
- ✅ Payment verification with proof
- ✅ Email confirmations

### Technical
- ✅ JSON file-based database (no external dependencies)
- ✅ Works on Node.js 10+
- ✅ No native dependencies (no GLIBC issues)
- ✅ Easy configuration via config.js
- ✅ Comprehensive documentation

---

## 🚀 Quick Start

### 1. Install
```bash
npm install
```

### 2. Configure
```bash
# Copy example config
cp config.example.js config.js

# Edit config.js with your settings
nano config.js
```

### 3. Run
```bash
npm start
```

Open http://localhost:3000

---

## 📧 Email Setup (Required)

### Gmail (Recommended for testing)

1. Create Gmail account
2. Enable 2FA in Google Account settings
3. Generate App Password: https://myaccount.google.com/security
4. Update `config.js`:

```javascript
email: {
    enabled: true,
    auth: {
        user: 'your-email@gmail.com',
        pass: 'xxxx xxxx xxxx xxxx' // App Password
    }
}
```

### SendGrid (Recommended for production)

```javascript
email: {
    enabled: true,
    host: 'smtp.sendgrid.net',
    auth: {
        user: 'apikey',
        pass: 'SG.your-api-key'
    }
}
```

### Disable Email (Testing only)

```javascript
email: {
    enabled: false
}
```

---

## 💳 Payment Setup

Update `config.js`:

```javascript
payment: {
    sbp: { phone: '+7 (900) 123-45-67' },
    p2p: { card: '2200 1234 5678 9012' },
    crypto: {
        btc: 'your-btc-address',
        eth: 'your-eth-address',
        usdt: 'your-usdt-address'
    }
}
```

---

## 📁 Project Structure

```
relentless/
├── server.js              # Main server file
├── config.js              # Configuration (create from config.example.js)
├── emailService.js        # Email service
├── package.json           # Dependencies
├── database/              # JSON database (auto-created)
│   ├── users.json
│   ├── subscriptions.json
│   ├── purchases.json
│   ├── tickets.json
│   └── activity.json
├── public/                # Frontend files
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── main.js
│       └── auth.js
└── docs/
    ├── QUICK_START.md     # Quick start guide
    ├── SETUP_GUIDE.md     # Complete setup guide
    └── CHECKLIST.md       # Feature checklist
```

---

## 🔒 Security Features

- **Password Requirements**: Minimum 8 characters, bcrypt hashed
- **Email Verification**: Mandatory before login
- **2FA**: 6-digit code sent to email (5 min expiry)
- **Rate Limiting**: 
  - Login: 5 attempts per 15 minutes
  - API: 100 requests per minute
- **Session Security**: 24-hour expiry, secure cookies
- **Activity Logging**: All actions logged with timestamp

---

## 📊 Database

All data stored in `./database/` as JSON files:

- `users.json` - User accounts
- `subscriptions.json` - Active/expired subscriptions
- `purchases.json` - Purchase history
- `tickets.json` - Support tickets
- `activity.json` - Activity logs

View data:
```bash
cat database/users.json
cat database/purchases.json
```

---

## 🎯 Subscription Plans

### External
- 7 Days - $2.49
- 1 Month - $19.99
- 3 Months - $49.99
- 6 Months - $89.99

### Internal
- 7 Days - $6.23
- 1 Month - $39.98
- 3 Months - $99.98
- 6 Months - $179.98

---

## 🌐 Production Deployment

### 1. HTTPS Setup (Required)

```bash
# Install Certbot
apt-get install certbot python3-certbot-nginx

# Get certificate
certbot --nginx -d your-domain.com
```

### 2. Update config.js

```javascript
sessionSecret: 'CHANGE-TO-RANDOM-STRING'
```

### 3. PM2 (Auto-restart)

```bash
npm install -g pm2
pm2 start server.js --name relentless
pm2 save
pm2 startup
```

### 4. Nginx Configuration

```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 📝 API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/verify-email` - Verify email with code
- `POST /api/resend-verification` - Resend verification code
- `POST /api/login` - Login (step 1)
- `POST /api/verify-2fa` - Verify 2FA code (step 2)
- `POST /api/logout` - Logout
- `GET /api/user` - Get current user info

### Payments
- `POST /api/payment/verify` - Verify payment and activate subscription
- `GET /api/purchases` - Get purchase history

### Support
- `POST /api/support` - Submit support ticket
- `GET /api/support/tickets` - Get user's tickets

---

## 🧪 Testing

1. Register with real email
2. Check email for verification code
3. Login with credentials
4. Check email for 2FA code
5. Purchase subscription
6. Check email for confirmation
7. View purchase history in account

---

## 🐛 Troubleshooting

### Email not sending
- Check `config.js` credentials
- For Gmail: use App Password, not regular password
- Check server logs for errors

### 2FA not working
- Ensure email is configured
- Code expires in 5 minutes
- Check `twoFactorEnabled: true` in config.js

### Rate limiting blocking
- Wait 15 minutes
- Or adjust limits in config.js

---

## 📚 Documentation

- [Quick Start Guide](QUICK_START.md) - Get started in 5 minutes
- [Complete Setup Guide](SETUP_GUIDE.md) - Detailed instructions
- [Feature Checklist](CHECKLIST.md) - What's implemented

---

## 🤝 Support

For issues or questions:
1. Check server logs
2. Review `database/activity.json`
3. Ensure all dependencies installed: `npm install`

---

## 📄 License

ISC License - © 2026 0x5team

---

## 🎉 Credits

**Kablykteam © 2026**

Built with:
- Node.js + Express
- Nodemailer
- Bcrypt
- Express Rate Limit
- Express Session

---

**Ready to deploy!** 🚀
