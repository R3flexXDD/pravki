# PHP API Integration Guide
**Connecting Website to Loader**

## Обзор

Сайт (Node.js) создает лицензии при покупке → PHP API проверяет лицензии → Loader использует API

```
[Website] → Purchase → [License Created] → [Email with Key]
                              ↓
[Loader] → Auth → [PHP API] → [Check License] → [Download DLL]
```

---

## Что уже сделано на сайте:

✅ При покупке автоматически создается лицензионный ключ
✅ Ключ отправляется на email пользователю
✅ Ключ отображается в аккаунте
✅ Можно копировать ключ
✅ Можно сбросить HWID

---

## Установка PHP API на сервер:

### 1. Подготовка

```bash
# Создай папку для API
mkdir /var/www/html/api
cd /var/www/html/api
```

### 2. Загрузи PHP файлы

Скопируй файлы из `api_extracted/api/` на сервер:
- `auth.php`
- `download.php`
- `heartbeat.php`
- `ban.php`
- `database.sql`

```bash
# Пример загрузки
scp api_extracted/api/*.php user@your-server.com:/var/www/html/api/
scp api_extracted/api/database.sql user@your-server.com:/var/www/html/api/
```

### 3. Настройка MySQL

```bash
# Войти в MySQL
mysql -u root -p

# Импортировать схему
mysql -u root -p < /var/www/html/api/database.sql

# Создать пользователя
CREATE USER 'relentless_api'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON relentless.* TO 'relentless_api'@'localhost';
FLUSH PRIVILEGES;
```

### 4. Настройка PHP файлов

Отредактируй в каждом PHP файле:

```php
$db_host = 'localhost';
$db_user = 'relentless_api';
$db_pass = 'your_secure_password';
$db_name = 'relentless';
```

В `download.php` укажи путь к DLL:
```php
$dll_path = '/var/www/html/api/relentless.dll';
```

### 5. Загрузи DLL

```bash
# Загрузи скомпилированный DLL на сервер
scp relentless.dll user@your-server.com:/var/www/html/api/

# Установи права
chmod 644 /var/www/html/api/relentless.dll
```

### 6. HTTPS (ОБЯЗАТЕЛЬНО!)

```bash
# Установи Certbot
apt-get install certbot python3-certbot-apache

# Получи сертификат
certbot --apache -d your-domain.com
```

---

## Синхронизация лицензий между сайтом и PHP API:

### Вариант 1: Скрипт синхронизации (Рекомендуется)

Создай `sync_licenses.js`:

```javascript
const fs = require('fs');
const mysql = require('mysql2/promise');

async function syncLicenses() {
    // Читаем лицензии из сайта
    const licenses = JSON.parse(fs.readFileSync('./database/licenses.json', 'utf8'));
    
    // Подключаемся к MySQL
    const connection = await mysql.createConnection({
        host: 'your-server.com',
        user: 'relentless_api',
        password: 'your_password',
        database: 'relentless'
    });
    
    // Синхронизируем каждую лицензию
    for (const license of licenses) {
        await connection.execute(
            `INSERT INTO licenses (license_key, hwid, active, expires_at, max_sessions, created_at)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
             hwid = VALUES(hwid),
             active = VALUES(active),
             expires_at = VALUES(expires_at)`,
            [
                license.license_key,
                license.hwid,
                license.active ? 1 : 0,
                license.expires_at,
                license.max_sessions,
                license.created_at
            ]
        );
    }
    
    await connection.end();
    console.log('✅ Licenses synced');
}

syncLicenses();
```

Запускай каждые 5 минут через cron:
```bash
*/5 * * * * cd /path/to/website && node sync_licenses.js
```

### Вариант 2: API Webhook (Автоматически)

Добавь в `server.js` после создания лицензии:

```javascript
// После: var license = licenseAPI.createLicense(...)

// Отправить на PHP API
const https = require('https');
const postData = JSON.stringify({
    license_key: license.license_key,
    expires_at: license.expires_at,
    max_sessions: license.max_sessions
});

const options = {
    hostname: 'your-domain.com',
    port: 443,
    path: '/api/sync_license.php',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': postData.length,
        'X-API-Key': 'your-secret-key' // Для безопасности
    }
};

const req = https.request(options);
req.write(postData);
req.end();
```

Создай `sync_license.php`:
```php
<?php
// Проверка API ключа
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($api_key !== 'your-secret-key') {
    die('Unauthorized');
}

$data = json_decode(file_get_contents('php://input'), true);

// Подключение к БД
$conn = new mysqli('localhost', 'relentless_api', 'password', 'relentless');

$stmt = $conn->prepare("INSERT INTO licenses (license_key, expires_at, max_sessions) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $data['license_key'], $data['expires_at'], $data['max_sessions']);
$stmt->execute();

echo "OK";
?>
```

---

## Обновление Loader:

В `loader.cpp` измени:

```cpp
#define SERVER_URL "https://your-domain.com/api"
```

Перекомпилируй loader.

---

## Тестирование:

### 1. Тест покупки на сайте
```bash
1. Зарегистрируйся на сайте
2. Купи подписку
3. Проверь email - должен быть лицензионный ключ
4. Зайди в аккаунт - ключ должен отображаться
```

### 2. Тест PHP API
```bash
# Тест auth.php
curl -X POST https://your-domain.com/api/auth.php \
  -d "hwid=test123&license=YOUR-LICENSE-KEY"

# Должен вернуть: SUCCESS:token
```

### 3. Тест Loader
```bash
1. Запусти loader
2. Введи лицензионный ключ
3. Loader должен авторизоваться и скачать DLL
```

---

## Мониторинг:

### Проверка лицензий в MySQL:
```sql
-- Все лицензии
SELECT * FROM licenses;

-- Активные лицензии
SELECT * FROM licenses WHERE active = 1 AND expires_at > NOW();

-- Активные сессии
SELECT s.*, l.license_key 
FROM sessions s 
JOIN licenses l ON s.license_id = l.id 
WHERE s.expires_at > NOW();
```

### Проверка лицензий на сайте:
```bash
cat database/licenses.json
```

---

## Управление лицензиями:

### Создать лицензию вручную (MySQL):
```sql
INSERT INTO licenses (license_key, expires_at, max_sessions) 
VALUES ('XXXX-XXXX-XXXX-XXXX', DATE_ADD(NOW(), INTERVAL 30 DAY), 1);
```

### Забанить HWID:
```sql
INSERT INTO banned_hwids (hwid, reason) 
VALUES ('abc123def456', 'Crack attempt');
```

### Деактивировать лицензию:
```sql
UPDATE licenses SET active = 0 WHERE license_key = 'XXXX-XXXX-XXXX-XXXX';
```

### Сбросить HWID (через сайт):
- Зайди в аккаунт
- Найди лицензию
- Нажми "Reset HWID"

---

## Безопасность:

✅ Используй только HTTPS
✅ Регулярно меняй пароли БД
✅ Ограничь доступ к API по IP (опционально)
✅ Включи rate limiting в Nginx/Apache
✅ Регулярно проверяй логи

---

## Troubleshooting:

**Лицензия не работает в loader:**
1. Проверь что лицензия есть в MySQL: `SELECT * FROM licenses WHERE license_key = 'YOUR-KEY'`
2. Проверь что active = 1
3. Проверь что expires_at > NOW()
4. Проверь что HWID не забанен

**Лицензия не создается при покупке:**
1. Проверь логи сервера
2. Проверь database/licenses.json
3. Проверь что licenseAPI.js работает

**Синхронизация не работает:**
1. Проверь подключение к MySQL
2. Проверь права пользователя БД
3. Проверь логи cron

---

## Итог:

✅ Сайт создает лицензии при покупке
✅ Лицензии отправляются на email
✅ Лицензии отображаются в аккаунте
✅ PHP API проверяет лицензии
✅ Loader использует PHP API
✅ Все работает вместе!

**Готово к использованию!** 🚀
