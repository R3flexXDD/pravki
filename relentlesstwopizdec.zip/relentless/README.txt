# RELENTLESS API Backend
**Kablykteam © 2026**

## Установка на сервер

### 1. Требования
- PHP 7.4 или выше
- MySQL 5.7 или выше
- HTTPS сертификат (обязательно!)
- Apache/Nginx веб-сервер

### 2. Настройка базы данных

```bash
# Войти в MySQL
mysql -u root -p

# Создать базу данных и импортировать схему
mysql -u root -p < database.sql

# Создать пользователя для API
CREATE USER 'relentless_api'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON relentless.* TO 'relentless_api'@'localhost';
FLUSH PRIVILEGES;
```

### 3. Настройка PHP файлов

Отредактируй в каждом файле (auth.php, download.php, heartbeat.php):

```php
$db_host = 'localhost';
$db_user = 'relentless_api';  // Твой пользователь
$db_pass = 'your_secure_password';  // Твой пароль
$db_name = 'relentless';
```

В `download.php` укажи путь к DLL:
```php
$dll_path = '/path/to/relentless.dll';  // Полный путь к DLL на сервере
```

### 4. Загрузка файлов на сервер

```bash
# Создай папку api на сервере
mkdir /var/www/html/api

# Загрузи файлы
scp auth.php download.php heartbeat.php user@your-server.com:/var/www/html/api/

# Установи права
chmod 644 /var/www/html/api/*.php
```

### 5. Настройка HTTPS

**ВАЖНО:** API должен работать только через HTTPS!

```bash
# Установи Certbot для Let's Encrypt
apt-get install certbot python3-certbot-apache

# Получи сертификат
certbot --apache -d your-server.com
```

### 6. Обновление loader.cpp

В файле `loader/loader.cpp` измени:

```cpp
#define SERVER_URL "https://your-server.com/api"
```

На твой реальный домен:

```cpp
#define SERVER_URL "https://relentless-cheat.com/api"
```

### 7. Создание лицензий

```sql
-- Лицензия на 30 дней, 1 сессия
INSERT INTO licenses (license_key, expires_at, max_sessions) 
VALUES ('XXXX-XXXX-XXXX-XXXX', DATE_ADD(NOW(), INTERVAL 30 DAY), 1);

-- Лицензия на 7 дней, 2 сессии
INSERT INTO licenses (license_key, expires_at, max_sessions) 
VALUES ('YYYY-YYYY-YYYY-YYYY', DATE_ADD(NOW(), INTERVAL 7 DAY), 2);

-- Lifetime лицензия
INSERT INTO licenses (license_key, expires_at, max_sessions) 
VALUES ('ZZZZ-ZZZZ-ZZZZ-ZZZZ', DATE_ADD(NOW(), INTERVAL 10 YEAR), 1);
```

### 8. Бан пользователей

```sql
-- Забанить по HWID
INSERT INTO banned_hwids (hwid, reason) 
VALUES ('abc123def456', 'Crack attempt detected');

-- Деактивировать лицензию
UPDATE licenses SET active = 0 WHERE license_key = 'XXXX-XXXX-XXXX-XXXX';
```

### 9. Мониторинг

```sql
-- Активные сессии
SELECT s.*, l.license_key 
FROM sessions s 
JOIN licenses l ON s.license_id = l.id 
WHERE s.expires_at > NOW();

-- Последние авторизации
SELECT * FROM auth_logs ORDER BY created_at DESC LIMIT 50;

-- Последние загрузки
SELECT * FROM download_logs ORDER BY created_at DESC LIMIT 50;

-- Heartbeat активность
SELECT * FROM heartbeat_logs ORDER BY created_at DESC LIMIT 100;
```

### 10. Безопасность

- Используй только HTTPS
- Регулярно меняй пароли БД
- Ограничь доступ к API по IP (опционально)
- Включи rate limiting в Apache/Nginx
- Регулярно проверяй логи на подозрительную активность

## Endpoints

### POST /api/auth.php
**Параметры:**
- `hwid` - Hardware ID пользователя
- `license` - Лицензионный ключ

**Ответы:**
- `SUCCESS:token` - Успешная авторизация, возвращает session token
- `ERROR:message` - Ошибка авторизации
- `BANNED:message` - HWID забанен

### POST /api/download.php
**Параметры:**
- `token` - Session token из auth.php

**Ответы:**
- Binary data - Зашифрованный DLL (с мутацией кода)
- `ERROR` - Ошибка загрузки
- `BANNED` - HWID забанен

### POST /api/heartbeat.php
**Параметры:**
- `token` - Session token

**Ответы:**
- `OK` - Сессия активна
- `INVALID` - Неверный токен
- `EXPIRED` - Лицензия истекла
- `BANNED` - HWID забанен

## Защита от кряка

### Code Mutation
Каждая загрузка DLL уникальна:
- Добавляются случайные байты (1-4 KB)
- Меняется сигнатура файла
- Невозможно создать универсальный кряк

### Session Validation
- Heartbeat каждые 30 секунд
- Автоматическое отключение при бане
- Проверка HWID на каждом запросе

### Anti-Debug
- Убивает отладчики перед запуском
- Детектирует VM/Sandbox
- Self-destruct при обнаружении

## Troubleshooting

**Ошибка "Connection failed":**
- Проверь SERVER_URL в loader.cpp
- Убедись что сервер доступен
- Проверь HTTPS сертификат

**Ошибка "Invalid license":**
- Проверь что лицензия есть в БД
- Проверь что active = 1
- Проверь expires_at

**Ошибка "Download failed":**
- Проверь путь к DLL в download.php
- Проверь права на чтение файла
- Проверь размер DLL (должен быть > 1000 байт)
