// License Management API for Loader Integration
// This connects the website purchases to the PHP loader API

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const LICENSES_FILE = path.join('./database', 'licenses.json');

// Ensure database directory exists
const DB_DIR = './database';
if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
}

// Initialize licenses file
if (!fs.existsSync(LICENSES_FILE)) {
    fs.writeFileSync(LICENSES_FILE, JSON.stringify([], null, 2));
}

// Helper functions
function readLicenses() {
    try {
        return JSON.parse(fs.readFileSync(LICENSES_FILE, 'utf8'));
    } catch (err) {
        console.error('Error reading licenses:', err);
        return [];
    }
}

function writeLicenses(licenses) {
    try {
        fs.writeFileSync(LICENSES_FILE, JSON.stringify(licenses, null, 2));
        return true;
    } catch (err) {
        console.error('Error writing licenses:', err);
        return false;
    }
}

// Generate license key (format: XXXX-XXXX-XXXX-XXXX)
function generateLicenseKey() {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var parts = [];
    
    for (var i = 0; i < 4; i++) {
        var part = '';
        for (var j = 0; j < 4; j++) {
            part += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        parts.push(part);
    }
    
    return parts.join('-');
}

// Calculate expiry date based on plan
function calculateExpiryDate(plan) {
    var days = 0;
    if (plan.indexOf('7 Days') !== -1) days = 7;
    else if (plan.indexOf('1 Month') !== -1) days = 30;
    else if (plan.indexOf('3 Months') !== -1) days = 90;
    else if (plan.indexOf('6 Months') !== -1) days = 180;
    
    var expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + days);
    return expiryDate.toISOString();
}

// Create license after purchase
function createLicense(userId, plan, type) {
    var licenses = readLicenses();
    
    var licenseKey = generateLicenseKey();
    var expiresAt = calculateExpiryDate(plan);
    
    var newLicense = {
        id: licenses.length > 0 ? Math.max.apply(Math, licenses.map(function(l) { return l.id; })) + 1 : 1,
        license_key: licenseKey,
        user_id: userId,
        plan: plan,
        type: type,
        hwid: null, // Will be bound on first use
        active: true,
        expires_at: expiresAt,
        max_sessions: 1, // Can be changed based on plan
        created_at: new Date().toISOString()
    };
    
    licenses.push(newLicense);
    writeLicenses(licenses);
    
    console.log('✅ License created: ' + licenseKey + ' for user ' + userId);
    
    return newLicense;
}

// Get user's licenses
function getUserLicenses(userId) {
    var licenses = readLicenses();
    return licenses.filter(function(l) { return l.user_id === userId; });
}

// Get active licenses
function getActiveLicenses(userId) {
    var licenses = getUserLicenses(userId);
    var now = new Date();
    
    return licenses.filter(function(l) {
        return l.active && new Date(l.expires_at) > now;
    });
}

// Deactivate license
function deactivateLicense(licenseKey) {
    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });
    
    if (license) {
        license.active = false;
        writeLicenses(licenses);
        return true;
    }
    
    return false;
}

// Reset HWID (unbind license)
function resetHWID(licenseKey) {
    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });
    
    if (license) {
        license.hwid = null;
        writeLicenses(licenses);
        return true;
    }
    
    return false;
}

module.exports = {
    createLicense: createLicense,
    getUserLicenses: getUserLicenses,
    getActiveLicenses: getActiveLicenses,
    deactivateLicense: deactivateLicense,
    resetHWID: resetHWID,
    generateLicenseKey: generateLicenseKey
};
