# RELENTLESS - Complete Setup Guide
**Kablykteam © 2026**

## ✅ Что уже сделано:

### Безопасность
- ✅ Email верификация (обязательная)
- ✅ 2FA через email (автоматически включена)
- ✅ Rate limiting (5 попыток логина / 15 минут)
- ✅ Bcrypt хеширование паролей (10 rounds)
- ✅ Минимум 8 символов для пароля
- ✅ Логирование всех действий

### Функционал
- ✅ История покупок
- ✅ Email уведомления (регистрация, 2FA, покупка)
- ✅ Автоматическое истечение подписок
- ✅ Support ticket система
- ✅ JSON база данных (без внешних зависимостей)

### Платежи
- ✅ SBP, P2P Card, Crypto (BTC, ETH, USDT)
- ✅ Проверка платежей с доказательствами
- ✅ Email подтверждение покупки

---

## 📧 Настройка Email (ОБЯЗАТЕЛЬНО!)

### Вариант 1: Gmail (Рекомендуется для тестирования)

1. Создай Gmail аккаунт для сайта
2. Включи 2FA в настройках Google
3. Создай App Password:
   - Зайди в https://myaccount.google.com/security
   - Найди "App passwords"
   - Создай новый пароль для "Mail"
   - Скопируй 16-значный пароль

4. Открой `config.js` и измени:
```javascript
email: {
    enabled: true,
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: 'your-email@gmail.com', // Твой Gmail
        pass: 'xxxx xxxx xxxx xxxx' // App Password (16 символов)
    },
    from: 'Relentless <noreply@relentless.com>'
}
```

### Вариант 2: SendGrid (Для продакшена)

1. Зарегистрируйся на https://sendgrid.com
2. Получи API ключ
3. В `config.js`:
```javascript
email: {
    enabled: true,
    service: 'smtp',
    host: 'smtp.sendgrid.net',
    port: 587,
    secure: false,
    auth: {
        user: 'apikey',
        pass: 'SG.xxxxxxxxxxxxxxxxxxxxxxxxx' // Твой API ключ
    },
    from: 'Relentless <noreply@your-domain.com>'
}
```

### Вариант 3: Mailgun

1. Зарегистрируйся на https://mailgun.com
2. Добавь свой домен
3. Получи SMTP credentials
4. В `config.js`:
```javascript
email: {
    enabled: true,
    service: 'smtp',
    host: 'smtp.mailgun.org',
    port: 587,
    secure: false,
    auth: {
        user: 'postmaster@your-domain.com',
        pass: 'your-mailgun-password'
    },
    from: 'Relentless <noreply@your-domain.com>'
}
```

### Отключить Email (только для тестирования!)

В `config.js`:
```javascript
email: {
    enabled: false, // Email отключен
    // ... остальное не важно
}
```

При отключенном email:
- Регистрация работает без верификации
- 2FA отключена
- Уведомления о покупках не отправляются

---

## 💳 Настройка платежных данных

Открой `config.js` и измени:

```javascript
payment: {
    sbp: {
        phone: '+7 (900) 123-45-67' // Твой номер для СБП
    },
    p2p: {
        card: '2200 1234 5678 9012' // Твоя карта
    },
    crypto: {
        btc: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh', // BTC адрес
        eth: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb', // ETH адрес
        usdt: 'TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9' // USDT (TRC20)
    }
}
```

---

## 🔒 Настройка безопасности

В `config.js` можешь изменить:

```javascript
security: {
    // Rate limiting
    loginAttempts: 5, // Макс попыток логина
    loginWindow: 15 * 60 * 1000, // За 15 минут
    apiRateLimit: 100, // Макс API запросов
    apiWindow: 60 * 1000, // За 1 минуту
    
    // 2FA
    twoFactorEnabled: true, // Включить/выключить 2FA
    twoFactorCodeExpiry: 5 * 60 * 1000, // Код действует 5 минут
    
    // Email verification
    emailVerificationRequired: true, // Обязательная верификация
    verificationCodeExpiry: 24 * 60 * 60 * 1000 // Код действует 24 часа
}
```

---

## 🚀 Запуск

### Локально (для разработки)

```bash
# Установить зависимости
npm install

# Запустить сервер
npm start

# Или с auto-reload
npm run dev
```

Сайт будет доступен на http://localhost:3000

### На хостинге

1. Загрузи все файлы КРОМЕ `node_modules/` и `database/`

2. На сервере выполни:
```bash
npm install
npm start
```

3. Для автозапуска используй PM2:
```bash
npm install -g pm2
pm2 start server.js --name relentless
pm2 save
pm2 startup
```

---

## 📊 База данных

Все данные хранятся в папке `./database/`:

- `users.json` - Пользователи
- `subscriptions.json` - Подписки
- `purchases.json` - История покупок
- `tickets.json` - Тикеты поддержки
- `activity.json` - Логи активности

### Просмотр данных

```bash
# Пользователи
cat database/users.json

# Активные подписки
cat database/subscriptions.json | grep "active"

# История покупок
cat database/purchases.json

# Логи
cat database/activity.json
```

---

## 🔐 HTTPS (ОБЯЗАТЕЛЬНО для продакшена!)

### С Certbot (Let's Encrypt)

```bash
# Установить Certbot
apt-get install certbot python3-certbot-nginx

# Получить сертификат
certbot --nginx -d your-domain.com

# Автообновление
certbot renew --dry-run
```

### В config.js измени:

```javascript
sessionSecret: 'CHANGE-THIS-TO-RANDOM-STRING-IN-PRODUCTION'
```

И в server.js (если используешь HTTPS):
```javascript
cookie: { 
    secure: true, // Включить для HTTPS
    maxAge: 24 * 60 * 60 * 1000
}
```

---

## 📝 Тестирование

### 1. Регистрация
- Зарегистрируйся с реальным email
- Проверь почту на код верификации
- Введи код

### 2. Логин
- Войди с email и паролем
- Проверь почту на 2FA код
- Введи код

### 3. Покупка
- Выбери тариф
- Выбери способ оплаты
- Введи любой proof (минимум 4 символа)
- Проверь email на подтверждение

### 4. История покупок
- Зайди в аккаунт
- Проверь что покупка отображается

---

## ⚠️ Важные замечания

### Для продакшена:

1. ✅ Настрой HTTPS
2. ✅ Измени `sessionSecret` в config.js
3. ✅ Настрой реальный email сервис
4. ✅ Добавь реальные платежные данные
5. ✅ Настрой автозапуск (PM2)
6. ✅ Настрой backup базы данных
7. ✅ Добавь мониторинг (UptimeRobot)

### Безопасность:

- Пароли хешируются с bcrypt
- Сессии истекают через 24 часа
- Rate limiting защищает от брутфорса
- Email верификация обязательна
- 2FA включена по умолчанию
- Все действия логируются

---

## 🐛 Troubleshooting

### Email не отправляется

1. Проверь `config.js` - правильные ли данные
2. Проверь что `enabled: true`
3. Для Gmail - используй App Password, не обычный пароль
4. Проверь логи сервера на ошибки

### 2FA не работает

1. Проверь что email отправляется
2. Проверь что `twoFactorEnabled: true` в config.js
3. Код действует только 5 минут

### Rate limiting блокирует

1. Подожди 15 минут
2. Или измени лимиты в config.js

### База данных не создается

1. Проверь права на запись в папку
2. Создай папку `database/` вручную

---

## 📞 Поддержка

Если что-то не работает:
1. Проверь логи сервера
2. Проверь `database/activity.json` на ошибки
3. Проверь что все зависимости установлены: `npm install`

---

## ✨ Что дальше?

### Рекомендуется добавить:

1. FAQ страницу
2. Реферальную систему
3. Админ панель
4. Telegram бот для поддержки
5. Cloudflare для защиты от DDoS

Все основные функции из `website_fixes.txt` реализованы!
