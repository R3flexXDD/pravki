// Loader API Endpoints
// Use these endpoints in your C++ loader

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const LICENSES_FILE = path.join('./database', 'licenses.json');
const USERS_FILE = path.join('./database', 'users.json');

// Helper functions
function readLicenses() {
    try {
        return JSON.parse(fs.readFileSync(LICENSES_FILE, 'utf8'));
    } catch (err) {
        return [];
    }
}

function writeLicenses(licenses) {
    try {
        fs.writeFileSync(LICENSES_FILE, JSON.stringify(licenses, null, 2));
        return true;
    } catch (err) {
        return false;
    }
}

function readUsers() {
    try {
        return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    } catch (err) {
        return [];
    }
}

// 1. AUTH - Validate license key and bind HWID
// POST /loader/auth
// Body: { "license": "XXXX-XXXX-XXXX-XXXX", "hwid": "hardware_id", "username": "nickname" }
router.post('/auth', function(req, res) {
    var licenseKey = req.body.license;
    var hwid = req.body.hwid;
    var username = req.body.username;

    if (!licenseKey || !hwid) {
        return res.json({
            success: false,
            message: 'Invalid request'
        });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.json({
            success: false,
            message: 'Invalid license key'
        });
    }

    // Check if expired
    if (new Date(license.expires_at) <= new Date()) {
        return res.json({
            success: false,
            message: 'License expired'
        });
    }

    // Check if active
    if (!license.active) {
        return res.json({
            success: false,
            message: 'License deactivated'
        });
    }

    // Verify username if provided
    if (username) {
        var users = readUsers();
        var user = users.find(function(u) { return u.id === license.user_id; });
        
        if (!user) {
            return res.json({
                success: false,
                message: 'User not found'
            });
        }

        // Check if username matches (case insensitive)
        if (user.name.toLowerCase() !== username.toLowerCase()) {
            return res.json({
                success: false,
                message: 'Invalid username'
            });
        }
    }

    // Bind HWID on first use
    if (!license.hwid) {
        license.hwid = hwid;
        writeLicenses(licenses);
    }

    // Check HWID match
    if (license.hwid !== hwid) {
        return res.json({
            success: false,
            message: 'HWID mismatch'
        });
    }

    // Success
    license.last_used = new Date().toISOString();
    writeLicenses(licenses);

    var users = readUsers();
    var user = users.find(function(u) { return u.id === license.user_id; });

    return res.json({
        success: true,
        message: 'Authentication successful',
        data: {
            username: user ? user.name : 'Unknown',
            plan: license.plan,
            type: license.type,
            expires_at: license.expires_at
        }
    });
});

// 2. HEARTBEAT - Keep session alive
// POST /loader/heartbeat
// Body: { "license": "XXXX-XXXX-XXXX-XXXX", "hwid": "hardware_id" }
router.post('/heartbeat', function(req, res) {
    var licenseKey = req.body.license;
    var hwid = req.body.hwid;

    if (!licenseKey || !hwid) {
        return res.json({ success: false });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license || !license.active || license.hwid !== hwid) {
        return res.json({ success: false });
    }

    if (new Date(license.expires_at) <= new Date()) {
        return res.json({ success: false });
    }

    license.last_heartbeat = new Date().toISOString();
    writeLicenses(licenses);

    return res.json({ success: true });
});

// 3. CHECK BAN - Check if user is banned
// POST /loader/ban
// Body: { "license": "XXXX-XXXX-XXXX-XXXX" }
router.post('/ban', function(req, res) {
    var licenseKey = req.body.license;

    if (!licenseKey) {
        return res.json({ banned: false });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.json({ banned: true });
    }

    return res.json({
        banned: !license.active,
        reason: license.active ? null : 'License deactivated'
    });
});

// 4. DOWNLOAD - Get cheat file (optional)
// GET /loader/download?license=XXXX-XXXX-XXXX-XXXX
router.get('/download', function(req, res) {
    var licenseKey = req.query.license;

    if (!licenseKey) {
        return res.status(400).json({ error: 'License required' });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license || !license.active) {
        return res.status(403).json({ error: 'Invalid license' });
    }

    if (new Date(license.expires_at) <= new Date()) {
        return res.status(403).json({ error: 'License expired' });
    }

    // Return download URL or file
    // For now, return a placeholder
    return res.json({
        success: true,
        download_url: 'https://your-cdn.com/relentless.dll',
        version: '1.0.0'
    });
});

// 5. INFO - Get license info
// GET /loader/info?license=XXXX-XXXX-XXXX-XXXX
router.get('/info', function(req, res) {
    var licenseKey = req.query.license;

    if (!licenseKey) {
        return res.status(400).json({ error: 'License required' });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.status(404).json({ error: 'License not found' });
    }

    return res.json({
        success: true,
        license: {
            key: license.license_key,
            plan: license.plan,
            type: license.type,
            active: license.active,
            expires_at: license.expires_at,
            hwid_bound: license.hwid ? true : false
        }
    });
});

module.exports = router;


// 6. VERIFY USERNAME - Check if username matches license owner
// POST /loader/verify-username
// Body: { "license": "XXXX-XXXX-XXXX-XXXX", "username": "nickname" }
router.post('/verify-username', function(req, res) {
    var licenseKey = req.body.license;
    var username = req.body.username;

    if (!licenseKey || !username) {
        return res.json({
            success: false,
            message: 'License and username required'
        });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.json({
            success: false,
            message: 'Invalid license'
        });
    }

    var users = readUsers();
    var user = users.find(function(u) { return u.id === license.user_id; });

    if (!user) {
        return res.json({
            success: false,
            message: 'User not found'
        });
    }

    // Check username match (case insensitive)
    if (user.name.toLowerCase() === username.toLowerCase()) {
        return res.json({
            success: true,
            message: 'Username verified',
            username: user.name
        });
    } else {
        return res.json({
            success: false,
            message: 'Username mismatch'
        });
    }
});

// 7. ANTI-CRACK CHECK - Verify loader integrity
// POST /loader/integrity
// Body: { "license": "XXXX-XXXX-XXXX-XXXX", "hwid": "hardware_id", "hash": "loader_hash" }
router.post('/integrity', function(req, res) {
    var licenseKey = req.body.license;
    var hwid = req.body.hwid;
    var hash = req.body.hash;

    if (!licenseKey || !hwid || !hash) {
        return res.json({
            success: false,
            cracked: true,
            message: 'Invalid request'
        });
    }

    // Valid loader hash (change this to your real loader hash)
    var VALID_LOADER_HASH = 'a1b2c3d4e5f6g7h8i9j0'; // Replace with real hash

    // Check if hash matches
    if (hash !== VALID_LOADER_HASH) {
        return res.json({
            success: false,
            cracked: true,
            message: 'Loader modified or cracked'
        });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.json({
            success: false,
            cracked: false,
            message: 'Invalid license'
        });
    }

    // Check HWID
    if (license.hwid && license.hwid !== hwid) {
        return res.json({
            success: false,
            cracked: false,
            message: 'HWID mismatch'
        });
    }

    return res.json({
        success: true,
        cracked: false,
        message: 'Integrity verified'
    });
});

// 8. GET USERNAME BY LICENSE
// GET /loader/username?license=XXXX-XXXX-XXXX-XXXX
router.get('/username', function(req, res) {
    var licenseKey = req.query.license;

    if (!licenseKey) {
        return res.status(400).json({ error: 'License required' });
    }

    var licenses = readLicenses();
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.status(404).json({ error: 'License not found' });
    }

    var users = readUsers();
    var user = users.find(function(u) { return u.id === license.user_id; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    return res.json({
        success: true,
        username: user.name,
        email: user.email
    });
});
