const express = require('express');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const config = require('./config');
const emailService = require('./emailService');
const licenseAPI = require('./licenseAPI');

const app = express();
const PORT = config.port;

// Database files
const DB_DIR = './database';
const USERS_FILE = path.join(DB_DIR, 'users.json');
const SUBSCRIPTIONS_FILE = path.join(DB_DIR, 'subscriptions.json');
const TICKETS_FILE = path.join(DB_DIR, 'tickets.json');
const PURCHASES_FILE = path.join(DB_DIR, 'purchases.json');
const ACTIVITY_FILE = path.join(DB_DIR, 'activity.json');

// Create database directory
if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR);
}

// Initialize database files
function initDB() {
    if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
    if (!fs.existsSync(SUBSCRIPTIONS_FILE)) fs.writeFileSync(SUBSCRIPTIONS_FILE, JSON.stringify([], null, 2));
    if (!fs.existsSync(TICKETS_FILE)) fs.writeFileSync(TICKETS_FILE, JSON.stringify([], null, 2));
    if (!fs.existsSync(PURCHASES_FILE)) fs.writeFileSync(PURCHASES_FILE, JSON.stringify([], null, 2));
    if (!fs.existsSync(ACTIVITY_FILE)) fs.writeFileSync(ACTIVITY_FILE, JSON.stringify([], null, 2));
}

initDB();

// Database helpers
function readDB(file) {
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
        console.error('Error reading database:', err);
        return [];
    }
}

function writeDB(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (err) {
        console.error('Error writing database:', err);
        return false;
    }
}

// Activity logger
function logActivity(userId, action, details) {
    var activities = readDB(ACTIVITY_FILE);
    activities.push({
        id: activities.length + 1,
        user_id: userId,
        action: action,
        details: details,
        ip: 'unknown',
        created_at: new Date().toISOString()
    });
    writeDB(ACTIVITY_FILE, activities);
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Rate limiting
const loginLimiter = rateLimit({
    windowMs: config.security.loginWindow,
    max: config.security.loginAttempts,
    message: { error: 'Too many login attempts, please try again later' }
});

const apiLimiter = rateLimit({
    windowMs: config.security.apiWindow,
    max: config.security.apiRateLimit,
    message: { error: 'Too many requests, please slow down' }
});

app.use('/api/', apiLimiter);

// Session configuration
app.use(session({
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Expire old subscriptions
function expireOldSubscriptions() {
    var subscriptions = readDB(SUBSCRIPTIONS_FILE);
    var now = new Date();
    var updated = false;

    for (var i = 0; i < subscriptions.length; i++) {
        if (subscriptions[i].status === 'active' && new Date(subscriptions[i].expires_at) <= now) {
            subscriptions[i].status = 'expired';
            updated = true;
        }
    }

    if (updated) writeDB(SUBSCRIPTIONS_FILE, subscriptions);
}

expireOldSubscriptions();
setInterval(expireOldSubscriptions, 60000);

console.log('✅ Database initialized');

// Helper: Generate random code
function generateCode(length) {
    var code = '';
    for (var i = 0; i < length; i++) {
        code += Math.floor(Math.random() * 10);
    }
    return code;
}

// API Routes

// Register
app.post('/api/register', loginLimiter, function(req, res) {
    var name = req.body.name;
    var email = req.body.email;
    var password = req.body.password;

    if (!name || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    if (password.length < 8) {
        return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }

    var users = readDB(USERS_FILE);
    var existingUser = users.find(function(u) { return u.email === email; });
    
    if (existingUser) {
        return res.status(400).json({ error: 'Email already registered' });
    }

    bcrypt.hash(password, 10, function(err, hashedPassword) {
        if (err) {
            console.error('Hash error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        var verificationCode = generateCode(6);
        var newUser = {
            id: users.length > 0 ? Math.max.apply(Math, users.map(function(u) { return u.id; })) + 1 : 1,
            name: name,
            email: email,
            password: hashedPassword,
            email_verified: !config.security.emailVerificationRequired,
            verification_code: verificationCode,
            verification_expires: new Date(Date.now() + config.security.verificationCodeExpiry).toISOString(),
            two_factor_enabled: config.security.twoFactorEnabled,
            created_at: new Date().toISOString()
        };

        users.push(newUser);
        writeDB(USERS_FILE, users);

        logActivity(newUser.id, 'register', 'User registered');

        // Send verification email
        if (config.security.emailVerificationRequired) {
            emailService.sendVerificationEmail(email, verificationCode, name);
        }

        console.log('✅ New user registered: ' + email + ' (ID: ' + newUser.id + ')');

        res.json({
            success: true,
            message: config.security.emailVerificationRequired ? 
                'Account created! Please check your email for verification code.' : 
                'Account created successfully',
            user: { email: email, name: name },
            requiresVerification: config.security.emailVerificationRequired
        });
    });
});

// Verify email
app.post('/api/verify-email', function(req, res) {
    var email = req.body.email;
    var code = req.body.code;

    if (!email || !code) {
        return res.status(400).json({ error: 'Email and code required' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.email === email; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (user.email_verified) {
        return res.json({ success: true, message: 'Email already verified' });
    }

    if (user.verification_code !== code) {
        return res.status(400).json({ error: 'Invalid verification code' });
    }

    if (new Date(user.verification_expires) < new Date()) {
        return res.status(400).json({ error: 'Verification code expired' });
    }

    user.email_verified = true;
    user.verification_code = null;
    user.verification_expires = null;
    writeDB(USERS_FILE, users);

    logActivity(user.id, 'email_verified', 'Email verified');

    console.log('✅ Email verified: ' + email);

    res.json({ success: true, message: 'Email verified successfully' });
});

// Resend verification
app.post('/api/resend-verification', loginLimiter, function(req, res) {
    var email = req.body.email;

    if (!email) {
        return res.status(400).json({ error: 'Email required' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.email === email; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (user.email_verified) {
        return res.json({ success: true, message: 'Email already verified' });
    }

    var verificationCode = generateCode(6);
    user.verification_code = verificationCode;
    user.verification_expires = new Date(Date.now() + config.security.verificationCodeExpiry).toISOString();
    writeDB(USERS_FILE, users);

    emailService.sendVerificationEmail(email, verificationCode, user.name);

    res.json({ success: true, message: 'Verification code sent' });
});

// Login (Step 1)
app.post('/api/login', loginLimiter, function(req, res) {
    var email = req.body.email;
    var password = req.body.password;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.email === email; });

    if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    bcrypt.compare(password, user.password, function(err, validPassword) {
        if (err) {
            console.error('Compare error:', err);
            return res.status(500).json({ error: 'Server error' });
        }

        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        if (config.security.emailVerificationRequired && !user.email_verified) {
            return res.status(403).json({ 
                error: 'Please verify your email first',
                requiresVerification: true
            });
        }

        // 2FA enabled
        if (user.two_factor_enabled) {
            var twoFactorCode = generateCode(6);
            user.two_factor_code = twoFactorCode;
            user.two_factor_expires = new Date(Date.now() + config.security.twoFactorCodeExpiry).toISOString();
            writeDB(USERS_FILE, users);

            emailService.send2FAEmail(email, twoFactorCode, user.name);

            return res.json({
                success: true,
                requires2FA: true,
                message: '2FA code sent to your email'
            });
        }

        // No 2FA - login directly
        req.session.userId = user.id;
        req.session.user = { email: user.email, name: user.name };

        logActivity(user.id, 'login', 'User logged in');

        console.log('✅ User logged in: ' + email);

        res.json({
            success: true,
            message: 'Logged in successfully',
            user: { email: user.email, name: user.name }
        });
    });
});

// Login (Step 2 - 2FA)
app.post('/api/verify-2fa', loginLimiter, function(req, res) {
    var email = req.body.email;
    var code = req.body.code;

    if (!email || !code) {
        return res.status(400).json({ error: 'Email and code required' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.email === email; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (!user.two_factor_code || user.two_factor_code !== code) {
        return res.status(400).json({ error: 'Invalid 2FA code' });
    }

    if (new Date(user.two_factor_expires) < new Date()) {
        return res.status(400).json({ error: '2FA code expired' });
    }

    user.two_factor_code = null;
    user.two_factor_expires = null;
    writeDB(USERS_FILE, users);

    req.session.userId = user.id;
    req.session.user = { email: user.email, name: user.name };

    logActivity(user.id, 'login', 'User logged in with 2FA');

    console.log('✅ User logged in with 2FA: ' + email);

    res.json({
        success: true,
        message: 'Logged in successfully',
        user: { email: user.email, name: user.name }
    });
});

// Logout
app.post('/api/logout', function(req, res) {
    if (req.session.userId) {
        logActivity(req.session.userId, 'logout', 'User logged out');
    }
    req.session.destroy();
    res.json({ success: true, message: 'Logged out successfully' });
});

// Get current user
app.get('/api/user', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.id === req.session.userId; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    var subscriptions = readDB(SUBSCRIPTIONS_FILE);
    var now = new Date();
    var activeSubscription = null;

    for (var i = 0; i < subscriptions.length; i++) {
        if (subscriptions[i].user_id === user.id && 
            subscriptions[i].status === 'active' && 
            new Date(subscriptions[i].expires_at) > now) {
            activeSubscription = subscriptions[i];
            break;
        }
    }

    res.json({
        user: {
            email: user.email,
            name: user.name,
            email_verified: user.email_verified,
            subscription: activeSubscription ? {
                plan: activeSubscription.plan,
                type: activeSubscription.type,
                status: activeSubscription.status,
                expiresAt: activeSubscription.expires_at
            } : null,
            createdAt: user.created_at
        }
    });
});

// Get purchase history
app.get('/api/purchases', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var purchases = readDB(PURCHASES_FILE);
    var userPurchases = purchases.filter(function(p) { return p.user_id === req.session.userId; });

    res.json({ purchases: userPurchases });
});

// Submit support ticket
app.post('/api/support', function(req, res) {
    var name = req.body.name;
    var email = req.body.email;
    var message = req.body.message;

    if (!name || !email || !message) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    var tickets = readDB(TICKETS_FILE);
    var userId = req.session.userId || null;

    var newTicket = {
        id: tickets.length > 0 ? Math.max.apply(Math, tickets.map(function(t) { return t.id; })) + 1 : 1,
        user_id: userId,
        name: name,
        email: email,
        message: message,
        status: 'open',
        created_at: new Date().toISOString()
    };

    tickets.push(newTicket);
    writeDB(TICKETS_FILE, tickets);

    if (userId) logActivity(userId, 'support_ticket', 'Created ticket #' + newTicket.id);

    console.log('✅ Support ticket #' + newTicket.id + ' created by ' + email);

    res.json({
        success: true,
        message: 'Support ticket submitted successfully',
        ticketId: newTicket.id
    });
});

// Get user's support tickets
app.get('/api/support/tickets', function(req, res) {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var tickets = readDB(TICKETS_FILE);
    var userTickets = tickets.filter(function(t) { return t.email === req.session.user.email; });

    res.json({ tickets: userTickets });
});

// Get user's licenses
app.get('/api/licenses', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var licenses = licenseAPI.getUserLicenses(req.session.userId);
    res.json({ licenses: licenses });
});

// Get active licenses only
app.get('/api/licenses/active', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var licenses = licenseAPI.getActiveLicenses(req.session.userId);
    res.json({ licenses: licenses });
});

// Reset HWID for license
app.post('/api/licenses/reset-hwid', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var licenseKey = req.body.licenseKey;
    if (!licenseKey) {
        return res.status(400).json({ error: 'License key required' });
    }

    // Verify license belongs to user
    var licenses = licenseAPI.getUserLicenses(req.session.userId);
    var license = licenses.find(function(l) { return l.license_key === licenseKey; });

    if (!license) {
        return res.status(404).json({ error: 'License not found' });
    }

    var success = licenseAPI.resetHWID(licenseKey);
    if (success) {
        logActivity(req.session.userId, 'hwid_reset', 'Reset HWID for license ' + licenseKey);
        res.json({ success: true, message: 'HWID reset successfully' });
    } else {
        res.status(500).json({ error: 'Failed to reset HWID' });
    }
});

// Payment verification
app.post('/api/payment/verify', function(req, res) {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    var method = req.body.method;
    var plan = req.body.plan;
    var price = req.body.price;
    var proof = req.body.proof;

    if (!method || !plan || !price || !proof) {
        return res.status(400).json({ error: 'Missing payment information' });
    }

    if (proof.length < 4) {
        return res.status(400).json({ error: 'Invalid transaction proof' });
    }

    var users = readDB(USERS_FILE);
    var user = users.find(function(u) { return u.id === req.session.userId; });

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (config.security.emailVerificationRequired && !user.email_verified) {
        return res.status(403).json({ error: 'Please verify your email first' });
    }

    var type = plan.indexOf('Internal') !== -1 ? 'Internal' : 'External';

    var durationDays = 0;
    if (plan.indexOf('7 Days') !== -1) durationDays = 7;
    else if (plan.indexOf('1 Month') !== -1) durationDays = 30;
    else if (plan.indexOf('3 Months') !== -1) durationDays = 90;
    else if (plan.indexOf('6 Months') !== -1) durationDays = 180;

    if (durationDays === 0) {
        return res.status(400).json({ error: 'Invalid plan' });
    }

    var expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + durationDays);
    var expiresAtISO = expiresAt.toISOString();

    // Create subscription
    var subscriptions = readDB(SUBSCRIPTIONS_FILE);
    var newSubscription = {
        id: subscriptions.length > 0 ? Math.max.apply(Math, subscriptions.map(function(s) { return s.id; })) + 1 : 1,
        user_id: user.id,
        plan: plan,
        type: type,
        status: 'active',
        started_at: new Date().toISOString(),
        expires_at: expiresAtISO,
        payment_method: method,
        transaction_proof: proof
    };

    subscriptions.push(newSubscription);
    writeDB(SUBSCRIPTIONS_FILE, subscriptions);

    // Create purchase record
    var purchases = readDB(PURCHASES_FILE);
    var newPurchase = {
        id: purchases.length > 0 ? Math.max.apply(Math, purchases.map(function(p) { return p.id; })) + 1 : 1,
        user_id: user.id,
        plan: plan,
        type: type,
        price: price,
        payment_method: method,
        transaction_proof: proof,
        created_at: new Date().toISOString()
    };

    purchases.push(newPurchase);
    writeDB(PURCHASES_FILE, purchases);

    // Create license key for loader
    var license = licenseAPI.createLicense(user.id, plan, type);

    logActivity(user.id, 'purchase', 'Purchased ' + plan + ' for ' + price);

    // Send confirmation email with license key
    emailService.sendPurchaseEmail(user.email, user.name, plan, price, expiresAtISO, license.license_key);

    console.log('✅ Payment verified for ' + user.email);
    console.log('   Plan: ' + plan + ' (' + type + ')');
    console.log('   Method: ' + method);
    console.log('   Proof: ' + proof);
    console.log('   License: ' + license.license_key);
    console.log('   Expires: ' + expiresAtISO);

    res.json({
        success: true,
        message: 'Payment verified and subscription activated',
        subscription: {
            plan: plan,
            type: type,
            expiresAt: expiresAtISO
        },
        license: {
            key: license.license_key,
            expiresAt: license.expires_at
        }
    });
});

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, function() {
    console.log('🔥 Relentless site running on http://localhost:' + PORT);
    console.log('📊 Database: JSON files in ./database/');
    console.log('📧 Email: ' + (config.email.enabled ? 'Enabled' : 'Disabled'));
    console.log('🔒 2FA: ' + (config.security.twoFactorEnabled ? 'Enabled' : 'Disabled'));
    console.log('✉️  Email Verification: ' + (config.security.emailVerificationRequired ? 'Required' : 'Optional'));
});

process.on('SIGINT', function() {
    console.log('\n✅ Server shutting down');
    process.exit(0);
});
